<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Lsettings {
	#===============Bank list============#
	public function bank_list()
	{
		$CI =& get_instance();
		$CI->load->model('Settings');
        $CI->load->model('Groups');
		$bank_list = $CI->Settings->get_bank_list( );
		$i=0;
		if(!empty($bank_list)){		
			foreach($bank_list as $k=>$v){$i++;
			   $bank_list[$k]['sl']=$i;
			}
		}
                $gid= $CI->session->userdata('group_id'); 
                $uid= $CI->session->userdata('user_id');  
    
      
                $gp = $CI->Groups->get_group_by_name_id('admin', $uid, $gid);
                if($gp[0]["name"]=='admin'){
                   $update = 1; 
                   $delete = 1; 
                   $pos    = 1;
                }else{
                   $update = $CI->Groups->checkPermissions($gid, 'invoice-edit'); 
                   $delete = $CI->Groups->checkPermissions($gid, 'invoice-delete'); 
                   $pos    = $CI->Groups->checkPermissions($gid, 'pos-invoice');              
                }  

		$data = array(
				'title' => display('bank_list'),
				'bank_list' => $bank_list,
                                'update' => $update,
                                'delete' => $delete, 	
			);
		$bankList = $CI->parser->parse('settings/bank',$data,true);
		return $bankList;
	}

	#=============Bank show by id=======#
	public function bank_show_by_id($bank_id){
		$CI =& get_instance();
		$CI->load->model('Settings');
		$bank_list = $CI->Settings->get_bank_by_id($bank_id);
		$data = array(
				'title' => display('bank_update'),
				'bank_list' => $bank_list
			);
		$bankList = $CI->parser->parse('settings/edit_bank',$data,true);
		return $bankList;
	}
	#=============Bank Update by id=======#
	public function bank_update_by_id($bank_id){
		$CI =& get_instance();
		$CI->load->model('Settings');
		$bank_list = $CI->Settings->bank_update_by_id($bank_id);
		return true;
	}
	#==================bank statment show for income / expence ===============#
	public function bank_statment_show()
	{
		$CI =& get_instance();
		$CI->load->model('Settings');
		$bank_list = $CI->Settings->get_bank_list( );
		$bank_statment_by_income = $CI->Settings->get_bank_statment_income();
		$bank_statment_by_expence = $CI->Settings->get_bank_statment_expence();
		$data = array(
				'title' 					=> "Bank Statment",
				'bank_statment_by_income' 	=> $bank_statment_by_income,
				'bank_statment_by_expence' 	=> $bank_statment_by_expence,
				'bank_list' 			=> $bank_list		
			);

		$bankList = $CI->parser->parse('settings/bank_statment',$data,true);
		return $bankList;
	}




	#==================bank statment show for income/expance bankwise ===============#
	public function bank_statment_show_by_bankwise($bank_id)
	{ 
		$CI =& get_instance();
		$CI->load->model('Settings');
		$bank_statment_by_income_id = $CI->Settings->get_statment_income_bankwise($bank_id);
		$bank_statment_by_expence_id = $CI->Settings->get_statment_expence_bankwise($bank_id);
		$i=0;
		if(!empty($bank_statment_by_income_id)){		
			foreach($bank_statment_by_income_id as $k=>$v){$i++;
			   $bank_statment_by_income_id[$k]['sl']=$i;
			}
		}

		$i=0;
		if(!empty($bank_statment_by_expence_id)){		
			foreach($bank_statment_by_expence_id as $k=>$v){$i++;
			   $bank_statment_by_expence_id[$k]['sl']=$i;
			}
		}
		$data = array(
				'title' => "Bank Statment by Bankwise",
				'bank_statment_by_income_id' => $bank_statment_by_income_id,
				'bank_statment_by_expence_id' => $bank_statment_by_expence_id	
			);
		
		$bankList = $CI->parser->parse('settings/bank_statment_bankwise',$data,true);
		return $bankList;

	}

	#==================bank statment show for income/expance todaydate ===============#
	public function bank_statment_show_by_todaydate($today_date)
	{ 

		$CI =& get_instance();
		$CI->load->model('Settings');
		$bank_statment_by_income_todaydate = $CI->Settings->get_statment_income_todaydate($today_date);
		$bank_statment_by_expence_todaydate = $CI->Settings->get_statment_expence_todaydate($today_date);
		$bank_statment_by_income_todaydate_amount = $CI->Settings->get_statment_income_todaydate_total($today_date);
		$bank_statment_by_expence_todaydate_amount = $CI->Settings->get_statment_expence_todaydate_total($today_date);

   		$totalincome =$bank_statment_by_income_todaydate_amount[0]['amount'];

   		$totalexpence =$bank_statment_by_expence_todaydate_amount[0]['amount'];

   		$total_today =$totalincome - $totalexpence;

		$i=0;
		if(!empty($bank_statment_by_income_todaydate)){		
			foreach($bank_statment_by_income_todaydate as $k=>$v){$i++;
			   $bank_statment_by_income_todaydate[$k]['sl']=$i;
			}
		}

		$i=0;
		if(!empty($bank_statment_by_expence_todaydate)){		
			foreach($bank_statment_by_expence_todaydate as $k=>$v){$i++;
			   $bank_statment_by_expence_todaydate[$k]['sl']=$i;
			}
		}
		$data = array(
				'title' => "Bank Statment by Bankwise",
				'bank_statment_by_income_todaydate' => $bank_statment_by_income_todaydate,
				'bank_statment_by_expence_todaydate' => $bank_statment_by_expence_todaydate,
				'totalincome'=>$totalincome,
				'totalexpence' =>$totalexpence,
				'total_today'=>$total_today
			);
	/*	echo "<pre>";
		print_r($data);
		exit;*/
		$bankList = $CI->parser->parse('settings/bank_statment_today',$data,true);
		return $bankList;

	}


	#============Table List=============#
	public function table_list()
	{
		$CI =& get_instance();
		$CI->load->model('Settings');
                $CI->load->model('Groups');
		$bank_list = $CI->Settings->table_list();
		$i=0;
		if(!empty($bank_list)){		
			foreach($bank_list as $k=>$v){$i++;
			   $bank_list[$k]['sl']=$i;
			}
		}
                $gid= $CI->session->userdata('group_id'); 
                $uid= $CI->session->userdata('user_id');  
    
      
                $gp = $CI->Groups->get_group_by_name_id('admin', $uid, $gid);
                if($gp[0]["name"]=='admin'){
                   $update = 1; 
                   $delete = 1; 
                   $pos    = 1;
                }else{
                   $update = $CI->Groups->checkPermissions($gid, 'invoice-edit'); 
                   $delete = $CI->Groups->checkPermissions($gid, 'invoice-delete'); 
                   $pos    = $CI->Groups->checkPermissions($gid, 'pos-invoice');              
                }  
		$data = array(
				'title' => display('account_list'),
				'table_list' => $bank_list,
                                'update' => $update,
                                'delete' => $delete, 	
			);
		$bankList = $CI->parser->parse('settings/table_list',$data,true);
		return $bankList;
	}
}
?>