<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Lsalary {
	#===============salary list============#
	public function salary_user_list()
	{

		$CI =& get_instance();
		$CI->load->model('Salary');
		$salary_data = $CI->Salary->salary_user_list_detail();
		$i=0;
		if(!empty($salary_data)){		
			foreach($salary_data as $k=>$v){$i++;
			   $salary_data[$k]['sl']=$i;
			}
		}
		$data = array(
				'salary_data' 	=> $salary_data
			);	

		$salary_list = $CI->parser->parse('salary/salary',$data,true);
		return $salary_list;
	}

	public function salary_user_details_list($user_id){
		$CI =& get_instance();
		$CI->load->model('Salary');
		$salary_list_details = $CI->Salary->get_staff_salary_by_id($user_id);
		$data = array(
						'title' 			=> "Salary details",
						'user_id' 			=> $salary_list_details[0]['user_id'],
						'name' 				=> $salary_list_details[0]['name'],
						'late_coming' 		=> $salary_list_details[0]['late_coming'],
						'over_times' 		=> $salary_list_details[0]['over_times'],
						'overtime_total' 	=> $salary_list_details[0]['overtime_total'],
						'half_day' 			=> $salary_list_details[0]['half_day'],
						'leave' 			=> $salary_list_details[0]['leave'],
						'balance_deduct_for_latecomming' 			=> $salary_list_details[0]['balance_deduct_for_latecomming'],
						'balance_deduct_for_halfday' 				=> $salary_list_details[0]['balance_deduct_for_halfday'],
						'balance_deduct_for_leave' 					=> $salary_list_details[0]['balance_deduct_for_leave'],
						'monthly_salary' 							=> $salary_list_details[0]['monthly_salary'],  
						'net_salary' 								=> $salary_list_details[0]['net_salary']
					);

				$salary_user_details = $CI->parser->parse('salary/details_user_salary',$data,true);
				return $salary_user_details;
	}














	
	#=============Bank show by id=======#
	public function bank_show_by_id($bank_id){
		$CI =& get_instance();
		$CI->load->model('Settings');
		$bank_list = $CI->Settings->get_bank_by_id($bank_id);
		$data = array(
				'title' => display('bank_update'),
				'bank_list' => $bank_list
			);
		$bankList = $CI->parser->parse('settings/edit_bank',$data,true);
		return $bankList;
	}

	#=============Bank Update by id=======#
	public function bank_update_by_id($bank_id){
		$CI =& get_instance();
		$CI->load->model('Settings');
		$bank_list = $CI->Settings->bank_update_by_id($bank_id);
		return true;
	}
	#============Table List=============#
	public function table_list()
	{
		$CI =& get_instance();
		$CI->load->model('Settings');
                $CI->load->model('Groups');
		$bank_list = $CI->Settings->table_list();
		$i=0;
		if(!empty($bank_list)){		
			foreach($bank_list as $k=>$v){$i++;
			   $bank_list[$k]['sl']=$i;
			}
		}
                $gid= $CI->session->userdata('group_id'); 
                $uid= $CI->session->userdata('user_id');  
    
      
                $gp = $CI->Groups->get_group_by_name_id('admin', $uid, $gid);
                if($gp[0]["name"]=='admin'){
                   $update = 1; 
                   $delete = 1; 
                   $pos    = 1;
                }else{
                   $update = $CI->Groups->checkPermissions($gid, 'invoice-edit'); 
                   $delete = $CI->Groups->checkPermissions($gid, 'invoice-delete'); 
                   $pos    = $CI->Groups->checkPermissions($gid, 'pos-invoice');              
                }  
		$data = array(
				'title' => display('account_list'),
				'table_list' => $bank_list,
                                'update' => $update,
                                'delete' => $delete, 	
			);
		$bankList = $CI->parser->parse('settings/table_list',$data,true);
		return $bankList;
	}
}
?>