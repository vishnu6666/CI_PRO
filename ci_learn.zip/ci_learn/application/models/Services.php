<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Services extends CI_Model {
	public function __construct()
	{
		parent::__construct();
	}
	//Count Product
	public function count_product()
	{
		return $this->db->count_all("services_information");
	}
	//Product List
	public function services_list()
	{
		$query=$this->db->select('services_information.*,users.*')
				->from('services_information')
				->join('users', 'services_information.staff_id = users.user_id')
				//->order_by('services_information.supplier_id','desc')
				->order_by('services_information.product_id','desc')
				->limit('500')
				->get();
		if ($query->num_rows() > 0) {
		 	return $query->result_array();	
		}
		return false;

	}
	
	
	public function staff_name_list_by_multipal_entry($value)
	{
		//print_r($value);
		$this->db->select('first_name,last_name,user_id');
		$this->db->from('users');
		//$this->db->where('status',1);
		$this->db->where('user_id',$value);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result_array();	
			//return TRUE;
	}
}


		//service add 
	public function service_entry($data)
	{
		$this->db->select('*');
		$this->db->from('services_information');
		$this->db->where('status',1);
		$this->db->where('services_name',$data['services_name']);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return FALSE;
		}else{
		   	$this->db->insert('services_information',$data);
			$this->db->select('*');
			$this->db->from('services_information');
			$this->db->where('status',1);
			$this->db->order_by('services_name','asc');
			$query = $this->db->get();
			foreach ($query->result() as $row) {
				$json_service[] = array('label'=>$row->services_name,'value'=>$row->product_id);
		}
			$cache_file = './my-assets/js/admin_js/json/service.json';
			$serviceList = json_encode($json_service);
			file_put_contents($cache_file,$serviceList);
			return TRUE;
		}
	}

	//Retrieve Product Edit Data
	public function retrieve_services_editdata($product_id)
	{
		/*$this->db->select('*');
		$this->db->from('services_information');
		$this->db->where('product_id',$product_id);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result_array();	
		}
		return false;*/
		
		 $query=$this->db->select('services_information.*,users.*')
				->from('services_information')
				->join('users', 'services_information.staff_id = users.user_id')				
				->where('product_id',$product_id)
				->limit('500')
				->get();
		if ($query->num_rows() > 0) {
		 	return $query->result_array();	
		}  	
		return false;	
	}
	 public function product_mapping_list()
	{
		$query=$this->db->select('product_mapping.*,services_information.*')
				->from('product_mapping')
				->join('services_information', 'services_information.product_id = product_mapping.product_id','left')
				
				->group_by('services_information.product_id','desc')
				->limit('500')
				->get();
		if ($query->num_rows() > 0) {
		 	return $query->result_array();	
		}
		return false;

	}
	
      public function manufacture_list()
	{
		$query=$this->db->select('manufacture.id, manufacture.quantity, manufacture.product_id,services_information.product_name')
				->from('manufacture')
				->join('services_information', 'services_information.product_id = manufacture.product_id','left')
				
				->group_by('services_information.product_id','desc')
				->limit('500')
				->get();
		if ($query->num_rows() > 0) {
		 	return $query->result_array();	
		}
		return false;

	}
	  public function manufacture_entry($data)
	{
            $product_id = $this->input->post('product_id');
            $prquantity = $this->input->post('quantity');

            $this->db->select('*');
	    $this->db->from('product_mapping');           
	    $this->db->where('product_id',$product_id);          
	    $query2 = $this->db->get();
	    foreach ($query2->result() as $row) {

             $data1=array(
			'purchase_detail_id'   =>  '',
			'product_id'	       =>  $row->map_product_id,
			'quantity'             =>  $prquantity * $row->quantity			
		);
		$this->db->insert('product_mapping_details',$data1);

	    }
            $this->db->insert('manufacture',$data);		
	    return true;
	}
        public function product_mapping_entry()
	{

                $product_id = $this->input->post('product_id');
                $row_product_id = $this->input->post('row_product_id');
				$quantity = $this->input->post('product_quantity');
                $price = $this->input->post('product_rate');
		
		
		for ($i=0, $n=count($row_product_id); $i < $n; $i++) {
			$product_quantity = $quantity[$i];	
                        $product_price= $price[$i];			
			$map_product_id = $row_product_id[$i];	
                        $total_price = 	$product_quantity * $product_price;	
			
			$data1 = array(					
				'product_id'		=>	$product_id,
				'quantity'		=>	$product_quantity,
                                'price'		        =>	$product_price,
				'map_product_id'	=>	$map_product_id,
                                'total_price'		=>	$total_price

				
			);

			$this->db->insert('product_mapping',$data1);
			
		}
         
	    return true;
	}
	public function retrieve_product_mapping_editdata($product_id)
	{
                 $query=$this->db->select('product_mapping.price as pprice, product_mapping.total_price as tpprice, product_mapping.*,services_information.*')
				->from('product_mapping')
				->join('services_information', 'services_information.product_id = product_mapping.map_product_id','left')
				->where('product_mapping.product_id',$product_id)
				->order_by('product_mapping.map_product_id','desc')
				->limit('500')
				->get();
		if ($query->num_rows() > 0) {
		 	return $query->result_array();	
		}  		
		return false;
	}
       public function retrieve_manufacture_editdata($id)
	{
                 $query=$this->db->select('manufacture.*,services_information.*')
				->from('manufacture')
				->join('services_information', 'services_information.product_id = manufacture.product_id','left')				
				->where('manufacture.id', $id)
				->limit('500')
				->get();
		if ($query->num_rows() > 0) {
		 	return $query->result_array();	
		}  		
		return false;
	}
	public function update_product_mapping($product_id)
	{
               $this->delete_mappingproduct($product_id);
                $product_id = $this->input->post('product_id');
                $row_product_id = $this->input->post('row_product_id');
		$quantity = $this->input->post('product_quantity');
		$price= $this->input->post('product_price');
		
		
		for ($i=0, $n=count($row_product_id); $i < $n; $i++) {
			$product_quantity = $quantity[$i];	
                        $product_price = $price[$i];			
			$map_product_id = $row_product_id[$i];			
			$total_price = 	$product_quantity * $product_price;	

			$data1 = array(					
				'product_id'		=>	$product_id,
				'quantity'		=>	$product_quantity,
                                'price'		=>	$product_price,
				'map_product_id'	=>	$map_product_id,
                                'total_price'		=>	$total_price 

				
			);

			$this->db->insert('product_mapping',$data1);
			
		}

		return true;
	} 
       public function update_manufacture($id)
	{
               
                
                $product_id = $this->input->post('product_id');
		$quantity = $this->input->post('quantity');
		
				
			$data1 = array(				
				
                                'product_id'		=>	$product_id,
				'quantity'		=>	$quantity
				
			);
                        $this->db->where('id',$id);
		        $this->db->update('manufacture',$data1);
			
			
		
		return true;
	} 
	//Product tax list
	public function retrieve_product_tax(){
		$result = $this->db->select('*')
                    ->from('tax_information')
                    ->get()
                    ->result();

        return $result;
	}
	//Tax selected item
	public function tax_selected_item($tax_id){
		$result = $this->db->select('*')
                    ->from('tax_information')
                    ->where('tax_id',$tax_id)
                    ->get()
                    ->result();

        return $result;
	}

	//Product generator id check 
	public function product_id_check($product_id){
		$query=$this->db->select('*')
				->from('services_information')
				->where('product_id',$product_id)
				->get();
		if ($query->num_rows() > 0) {
		 	return true;	
		}else{
			return false;
		}
	}
	
	//Retrieve company Edit Data
	public function retrieve_company()
	{
		$this->db->select('*');
		$this->db->from('company_information');
		$this->db->limit('1');
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result_array();	
		}
		return false;
	}
	//Update Categories
	public function update_services($data,$service_id)
	{

		$this->db->where('product_id',$service_id);
		$this->db->update('services_information',$data); 		    
		$this->db->select('*');
		$this->db->from('services_information');
		$this->db->where('status',1);
		$query = $this->db->get();
		
		foreach ($query->result() as $row) {
			$json_service[] = array('label'=>$row->services_name,'value'=>$row->product_id);
		}
		$cache_file = './my-assets/js/admin_js/json/service.json';
		$productList = json_encode($json_service);
		file_put_contents($cache_file,$productList);
		return true;
	}
	 public function delete_mappingproduct($product_id)
	{

		$this->db->where('product_id',$product_id);
		$this->db->delete('product_mapping'); 		
		return true;
		
	}
public function delete_mapping_product($product_id)
	{

		$this->db->where('product_id',$product_id);
		$this->db->delete('product_mapping'); 
		$this->session->set_userdata(array('message'=>display('successfully_delete')));
		return true;
		
	}
       public function delete_manufacture($id)
	{

		$this->db->where('id',$id);
		$this->db->delete('manufacture'); 
		$this->session->set_userdata(array('message'=>display('successfully_delete')));
		return true;
		
	}
	// Delete Product Item
	public function delete_service($service_id)
	{

		#### Check product is using on system or not##########
		# If this product is used any calculation you can't delete this product.
		# but if not used you can delete it from the system.
		$this->db->select('product_id');
		$this->db->from('product_purchase_details');
		$this->db->where('product_id',$service_id);
		$query = $this->db->get();
		$affected_row=$this->db->affected_rows();

		if($affected_row == 0) {
			$this->db->where('product_id',$service_id);
			$this->db->delete('services_information'); 
			$this->session->set_userdata(array('message'=>display('successfully_delete')));
            
           // $this->db->select('a.product_name, a.product_id, b.batch_no');
		   // $this->db->from('services_information a');
		   // $this->db->join('product_purchase_details b','b.product_id = a.product_id');
		   // $this->db->where('a.status',1);
		   // $this->db->group_by('a.product_id');
		   // $this->db->order_by('b.expire_date','desc');
		
			$this->db->select('*');
			$this->db->from('services_information');
			$this->db->where('status',1);
			$query = $this->db->get();
			foreach ($query->result() as $row) {
				$json_product[] = array('label'=>$row->product_name,'value'=>$row->product_id);
				//$json_product[] = array('label'=>$row->product_name.'('.$row->batch_no.')','value'=>$row->product_id);
			}
			$cache_file = './my-assets/js/admin_js/json/product.json';
			$productList = json_encode($json_product);
			file_put_contents($cache_file,$productList);
			return true;
		}else{
			$this->session->set_userdata(array('message'=>display('you_cant_delete_this_product')));
			return false;
		}	
	}
	//Product By Search 
	public function product_search_item($product_id)
	{

		$this->db->select('supplier_information.*,services_information.*');
		$this->db->from('services_information');
		$this->db->join('supplier_information', 'services_information.supplier_id = supplier_information.supplier_id','left');
		$this->db->where('product_id',$product_id);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result_array();	
		}
		return false;
	}	
	
	//Duplicate Entry Checking 
	public function product_model_search($product_name)
	{
		$this->db->select('*');
		$this->db->from('services_information');
		$this->db->where('product_name',$product_name);
		$query = $this->db->get();
		return $this->db->affected_rows();
	}	
	//Product Details
	public function product_details_info($product_id)
	{
		$this->db->select('*');
		$this->db->from('services_information');
		$this->db->where('product_id',$product_id);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result_array();	
		}
		return false;
	}
	// Product Purchase Report
	public function product_purchase_info($product_id)
	{
		$this->db->select('a.*,b.*,c.supplier_name');
		$this->db->from('product_purchase a');
		$this->db->join('product_purchase_details b','b.purchase_id = a.purchase_id');
		$this->db->join('supplier_information c','c.supplier_id = a.supplier_id');
		$this->db->where('b.product_id',$product_id);
		$this->db->order_by('a.purchase_id','asc');
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result_array();	
		}
		return false;
	}
	// Invoice Data for specific data
	public function invoice_data($product_id)
	{
		$this->db->select('a.*,b.*,c.customer_name');
		$this->db->from('invoice a');
		$this->db->join('invoice_details b','b.invoice_id = a.invoice_id');
		$this->db->join('customer_information c','c.customer_id = a.customer_id');
		$this->db->where('b.product_id',$product_id);
		$this->db->order_by('a.invoice_id','asc');
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result_array();	
		}
		return false;
	}
	public function previous_stock_data($product_id,$startdate)
	{
		$startdate.=" 00:00:00";
		
		$this->db->select('date,sum(quantity) as quantity');
		$this->db->from('product_report');
		$this->db->where('product_id',$product_id);
		$this->db->where('date <=',$startdate);
		$query = $this->db->get();
		//echo $this->db->last_query();
		if ($query->num_rows() > 0) {
			return $query->result_array();	
		}
		return false;
	
	}
// Invoice Data for specific data
	public function invoice_data_supplier_rate($product_id,$startdate,$enddate)
	{


		$startdate.=" 00:00:00";
		$enddate.=" 00:00:00";
		
		$this->db->select('date,sum(quantity) as quantity,rate,-rate*sum(quantity) as total_price,account');
		$this->db->from('product_report');
		$this->db->where('product_id',$product_id);
		$this->db->where('date >=',$startdate);
		$this->db->where('date <=',$enddate);
		$this->db->group_by('date','account');
		$this->db->order_by('date','asc');
		$query = $this->db->get();
		//echo $this->db->last_query();
		if ($query->num_rows() > 0) {
			return $query->result_array();	
		}
		return false;
	}
	public function retrieve_product_purchase_data($product_id)
	{
	
		$this->db->select('a.*, b.quantity, b.id as prid');
		$this->db->from('services_information a');
		$this->db->join('product_purchase_details b','b.product_id = a.product_id');
		$this->db->where(array('a.product_id' => $product_id,'a.status' => 1)); 
		$services_information = $this->db->get()->row();
		
		$data2 = array(
			'supplier_price' => $services_information->supplier_price, 
			'price' => $services_information->price, 
			'ptr' => $services_information->ptr,  			
			'cgst_per' => $services_information->cgst_per, 
			'sgst_per' => $services_information->sgst_per, 
			'tax' => $services_information->tax, 
			'sgst' => $services_information->sgst, 
			'cgst_ptr' => $services_information->cgst_ptr, 
			'sgst_ptr' => $services_information->sgst_ptr,
			'quantity' => $services_information->quantity,
			'prid' => $services_information->prid,
			);
			
		return $data2;
	}
	public function product_transfer_entry($data){
		
		$this->db->select('a.quantity');
		$this->db->from('product_purchase_details a');	
		$this->db->where(array('a.id' => $this->input->post('prid'))); 
		$services_information = $this->db->get()->row();
		$qty= $services_information->quantity  - $this->input->post('transfer_product_quantity');
		$data2 = array(
			'quantity' => $qty
		
			);
		$this->db->where('id',$this->input->post('prid'));
		$this->db->update('product_purchase_details',$data2); 				
		$this->db->insert('product_transfered',$data);		
		return true;
	}	
	public function product_transfer_list(){
		$query=$this->db->select('a.*,d.product_name,d.product_id, c.*')
				->from('product_transfered a')
				->join('product_purchase_details b', 'a.purchase_detail_id = b.id','left')
				->join('services_information d', 'd.product_id = b.product_id','left')
				->join('company_information c', 'a.company_id = c.id','left')			
				->limit('500')
				->get();
		if ($query->num_rows() > 0) {
		 	return $query->result_array();	
		}
		return false;
		
	}	
}