<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Cpurchase extends CI_Controller {
	
	function __construct() {
      parent::__construct();
	  
	  $this->template->current_menu = 'purchase';
    }
	public function index()
	{	
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('lpurchase');
	
		$content = $CI->lpurchase->purchase_add_form();
		
		$this->template->full_admin_html_view($content);
		
	}
	public function add_purchase_return_form()
	{
	   $CI =& get_instance();
	   $CI->auth->check_admin_auth();
	    $CI->load->library('lpurchase');
		$content = $CI->lpurchase->purchase_return_add_form();
		$this->template->full_admin_html_view($content);
	
	}
	 public function manage_purchase_return()
	{	
		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->library('lpurchase');
		$CI->load->model('Purchases');
        $content = $CI->lpurchase->purchase_return_list();
		$this->template->full_admin_html_view($content);
	}
	//Product Add Form
	public function manage_purchase()
	{
		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->library('lpurchase');
		$CI->load->model('Purchases');
        $content = $CI->lpurchase->purchase_list();
        $this->db->select('price,product_id');
		    $this->db->from('product_information');
		    $this->db->where('status',1);
		    $query = $this->db->get();
		   	foreach ($query->result() as $row) {
				$query = $this->db->query("UPDATE `product_purchase_details` SET `mrp` = '".$row->price."' WHERE `product_purchase_details`.`product_id` = '".$row->product_id."'");
				
			}
      
		$this->template->full_admin_html_view($content);
	}
	//Insert Product and uload
	public function insert_purchase()
	{
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->model('Purchases');
		$purchase_id= $CI->Purchases->purchase_entry();
		$this->session->set_userdata(array('message'=>display('successfully_added')));
		if(isset($_POST['add-purchase'])){
		   
			redirect(base_url('Cpurchase/purchase_update_form/'.$purchase_id));
			exit;
		}elseif(isset($_POST['add-purchase-another'])){
			redirect(base_url('Cpurchase'));
			exit;
		}
	}
	//Insert Product and uload
	public function insert_purchase_return()
	{
	
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->model('Purchases');
		$CI->Purchases->purchase_return_entry();
		$this->session->set_userdata(array('message'=>display('successfully_added')));
		redirect(base_url('Cpurchase/manage_purchase'));
		exit;
	
	}
	//purchase Update Form
	public function purchase_update_form($purchase_id)
	{	
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('lpurchase');
		$content = $CI->lpurchase->purchase_edit_data($purchase_id);
		$this->template->full_admin_html_view($content);
	}
	// purchase Update
	public function purchase_update()
	{
	
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->model('Purchases');
		$CI->Purchases->update_purchase();
		$this->session->set_userdata(array('message'=>display('successfully_updated')));
		redirect(base_url('Cpurchase/manage_purchase'));
		exit;
	}
	// product_delete
	public function purchase_delete()
	{	
		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->model('Purchases');
		$purchase_id =  $_POST['purchase_id'];
		$CI->Purchases->delete_purchase($purchase_id);
		$this->session->set_userdata(array('message'=>display('successfully_delete')));
		return true;
			
	}
	//Purchase item by search
	public function purchase_item_by_search()
	{
		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->library('lpurchase');
		$supplier_id = $this->input->post('supplier_id');			
        $content = $CI->lpurchase->purchase_by_search($supplier_id);
		$this->template->full_admin_html_view($content);
	}
	//Product search by supplier id
	public function product_search_by_supplier(){

		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->library('lpurchase');
		$CI->load->model('Suppliers');
		$supplier_id = $this->input->post('supplier_id');			
        $content = $CI->Suppliers->product_search_item($supplier_id);

        if (empty($content)) {
        	echo "No Product Found !";
	    }else{
		
	    	// Select option created for product
	        echo "<select name=\"product_id[]\"  onChange=\"purchase_productList(1);\" class=\"productSelection js-example-basic-single form-control\" id=\"product_id\">";
	        	echo "<option value=\"0\">".display('select_one')."</option>";
	        	foreach ($content as $product) {
	    			echo "<option value=".$product['product_id'].">";
	    			echo $product['product_name'];
	    			echo "</option>"; 
	        	}	
	        echo "</select>";
	    }
	}
	public function purchase_product_search_by_supplier(){

		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->library('lpurchase');
		$CI->load->model('Purchases');
		$supplier_id = $this->input->post('supplier_id');			
        $content = $CI->Purchases->retrieve_return_purchase_editdata($supplier_id);

        if (empty($content)) {
        	echo "No Product Found !";
	    }else{
		
	    	// Select option created for product
			$k=1;
			foreach ($content as $product) {
	        echo '<tr><td class="span3 supplier"><input type="hidden" name="purchase_id[]" value="'.$product['purchase_id'].'" /><input type="hidden" name="product_id[]" value="'.$product['product_id'].'"/>'.$product['product_name'].'</td><td class="text-right"><input type="text" name="product_quantity[]" id="total_qntt_'.$k.'"  value="'.$product['quantity'].'" onchange="quantity_calculate('.$k.')"  class="form-control text-right" placeholder="quantity" min="0" /></td><td><input type="text" name="product_rate[]" value="'.$product['rate'].'"   id="price_item_'.$k.'" class="price_item1 text-right form-control" placeholder="rate" /></td><td class="text-right"><input class="total_price text-right form-control" type="text" name="total_price[]" id="total_price_'.$k.'" value="'.$product['total_amount'].'" tabindex="-1" readonly="readonly" /></td></tr>';
	        
			$k=$k+1;
			}
	        	
	    }
	}

	//Retrive right now inserted data to cretae html
	public function purchase_details_data($purchase_id)
	{	
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('lpurchase');
		$content = $CI->lpurchase->purchase_details_data($purchase_id);	
		$this->template->full_admin_html_view($content);
	}
}