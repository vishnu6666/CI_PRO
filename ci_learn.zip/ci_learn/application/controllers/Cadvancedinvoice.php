<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Cadvancedinvoice extends CI_Controller {
	
	function __construct() {
      parent::__construct();
      
	  
	  $this->template->current_menu = 'memo';
    }
	public function index()
	{

		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('ladvancedinvoice');
		$content = $CI->ladvancedinvoice->advancedinvoice_add_form();
		$this->template->full_admin_html_view($content);
	}
	//Search Inovoice Item
	public function add_return_wholesale()
	{
	   $CI =& get_instance();
	   $CI->auth->check_admin_auth();
	    $CI->load->library('ladvancedinvoice');
		$content = $CI->ladvancedinvoice->wholesale_return_add_form();
		$this->template->full_admin_html_view($content);
	
	}
	public function search_advancedinovoice_item()
	{
		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->library('ladvancedinvoice');
		
		$customer_id = $this->input->post('customer_id');
        $content = $CI->ladvancedinvoice->search_inovoice_item($customer_id);
		$this->template->full_admin_html_view($content);
	}
	//Product Add Form
	public function manage_advancedinvoice()
	{	
		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->library('ladvancedinvoice');
		$CI->load->model('Advancedinvoices');

               $content = $CI->ladvancedinvoice->advancedinvoice_list();

		$this->template->full_admin_html_view($content);
	}
	public function manage_wholesale_return()
	{	
		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->library('ladvancedinvoice');
		$CI->load->model('Advancedinvoices');
        $content = $CI->ladvancedinvoice->wholesale_return_list();
		$this->template->full_admin_html_view($content);
	}
	
	//POS advancedinvoice page load
	public function pos_advancedinvoice(){
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('ladvancedinvoice');
		$content = $CI->ladvancedinvoice->pos_advancedinvoice_add_form();
		$this->template->full_admin_html_view($content);
	}
    //Insert Product and uload
	public function insert_wholesale_return()
	{
	
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->model('Advancedinvoices');
		$CI->Advancedinvoices->wholesale_return_entry();
		$this->session->set_userdata(array('message'=>display('successfully_added')));
		redirect(base_url('Cadvancedinvoice/manage_wholesale_return'));
		exit;
	
	}
	//Insert pos advancedinvoice
	public function insert_pos_advancedinvoice()
	{
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->model('Advancedinvoices');
		$product_model = $this->input->post('product_model');
		
		$product_details = $CI->Advancedinvoices->pos_advancedinvoice_setup($product_model);

		$tr = " ";
		if (!empty($product_details)){
			$product_id = $this->generator(5);
			$tr .= "<tr id=\"row_".$product_id."\">
						<td class=\"\">
							
							<input type=\"text\" name=\"product_name\" onkeypress=\"advancedinvoice_productList(1);\" class=\"form-control productSelection \" value='".$product_details->product_name."- (".$product_details->product_id.")"."' placeholder='".display('product_name')."' required=\"\" id=\"product_name\" >


							<input type=\"hidden\" class=\"form-control autocomplete_hidden_value product_id_".$product_id."\" name=\"product_id[]\" id=\"SchoolHiddenId\" value = \"$product_details->product_id\" id=\"product_id\"/>
							
						</td>
						<td>
                            <input type=\"number\" name=\"available_quantity[]\" id=\"\" class=\"form-control text-right available_quantity_'".$product_details->product_id."'\" value='".$product_details->total_product."' readonly=\"\" />
                        </td>
						<td class=\"text-right\">
							<input type=\"number\" name=\"product_quantity[]\" onkeyup=\"quantity_calculate('".$product_id."');\" id=\"total_qntt_".$product_id."\" class=\"form-control text-right\" value=\"1\" min=\"1\"/>
						</td>
						<td class=\"\">
							<input type=\"number\" name=\"product_rate[]\" readonly=\"\" value='".$product_details->price."' id=\"price_item_".$product_id."\" class=\"price_item1 form-control text-right\" />
						</td>
						<td class=\"\">
							<input type=\"number\" name=\"discount[]\" onkeyup=\"quantity_calculate('".$product_id."');\" id=\"discount_".$product_id."\" class=\"form-control text-right\" placeholder=\"Discount\" value =\"0.00\"/>
						</td>
						<td class=\"text-right\">
							<input class=\"total_price form-control text-right\" type=\"text\" name=\"total_price[]\" id=\"total_price_".$product_id."\" value='".$product_details->price."' tabindex=\"-1\" readonly=\"readonly\"/>
						</td>
						<td>

							<input type=\"hidden\" id=\"total_tax_".$product_id."\" class=\"total_tax_1\" value='".$product_details->tax."'/>
                            <input type=\"hidden\" id=\"all_tax_".$product_id."\" class=\" total_tax\"/>

							<button style=\"text-align: right;\" class=\"btn btn-danger\" type=\"button\" value=\"Delete\" onclick=\"deleteRow(this)\">Delete</button>
						</td>
					</tr>";
			echo $tr;
		}else{
			return false;
		}
	}

	//Insert Product and uload
	public function insert_advancedinvoice()
	{
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->model('Advancedinvoices');
		$advancedinvoice_id = $CI->Advancedinvoices->advancedinvoice_entry();
		$this->session->set_userdata(array('message'=>display('successfully_added')));
		$this->advancedinvoice_inserted_data($advancedinvoice_id);
	}
	//advancedinvoice Update Form
	public function advancedinvoice_update_form($advancedinvoice_id)
	{	
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('ladvancedinvoice');
		$content = $CI->ladvancedinvoice->advancedinvoice_edit_data($advancedinvoice_id);
		$this->template->full_admin_html_view($content);
	}
	// advancedinvoice Update
	public function update_advancedinvoice()
	{
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->model('Advancedinvoices');
		$advancedinvoice_id = $CI->Advancedinvoices->update_advancedinvoice();
	
		$this->session->set_userdata(array('message'=>display('successfully_updated')));
		$this->advancedinvoice_inserted_data($advancedinvoice_id);
	}
	//Retrive right now inserted data to cretae html
	public function advancedinvoice_inserted_data($advancedinvoice_id)
	{	
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('ladvancedinvoice');
			              
		$content = $CI->ladvancedinvoice->advancedinvoice_html_data($advancedinvoice_id);		
		$this->template->full_admin_html_view($content);
	}
	public function p_data($advancedinvoice_id)
	{	
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('ladvancedinvoice');
			              
		$content = $CI->ladvancedinvoice->p_html_data($advancedinvoice_id);		
		$this->template->full_admin_html_view($content);
	}
	//Retrive right now inserted data to cretae html
	public function pos_advancedinvoice_inserted_data($advancedinvoice_id)
	{	
		$CI =& get_instance();
		$CI->auth->check_admin_auth();
		$CI->load->library('ladvancedinvoice');
		$content = $CI->ladvancedinvoice->pos_advancedinvoice_html_data($advancedinvoice_id);		
		$this->template->full_admin_html_view($content);
	}
	
	// retrieve_product_data
	public function retrieve_wholesale_return_product_data(){

		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->library('ladvancedinvoice');
		$CI->load->model('Advancedinvoices');
		$advancedinvoice_id = $this->input->post('advancedinvoice_id');			
        $content = $CI->Advancedinvoices->retrieve_return_wholesale_editdata($advancedinvoice_id);

        if (empty($content)) {
        	echo "No Product Found !";
	    }else{
		
	    	// Select option created for product
			$k=1;
			foreach ($content as $product) {
			
				
	        echo '<tr><td class="span3 supplier"><input type="hidden" name="product_id[]" value="'.$product['product_id'].'"/>'.$product['product_name'].'</td><td class="text-right"><input type="text" name="ptr[]" id="ptr_'.$k.'"  class="form-control text-right" placeholder="PTR" value="'.$product['ptr'].'" readonly="readonly"/></td><td class="text-right"><input type="text" name="product_quantity[]" id="total_qntt_'.$k.'"  value="'.$product['quantity'].'" onchange="quantity_calculate('.$k.')"  class="form-control text-right" placeholder="quantity" min="0" /></td><td><input type="text" name="product_rate[]" value="'.$product['rate'].'"   id="price_item_'.$k.'" class="price_item1 text-right form-control" placeholder="rate" /></td><td><input type="text" name="discount[]" onkeyup="quantity_calculate('.$k.');" id="discount_'.$k.'" class="form-control text-right" value="0" min="1" /></td><td class="text-right"><input class="total_price text-right form-control" type="text" name="total_price[]" id="total_price_'.$k.'" value="'.$product['tot_rate'].'" tabindex="-1" readonly="readonly" /></td></tr>';
	        
			$k=$k+1;
			}
	        	
	    }
	}

	public function retrieve_product_data()
	{	

		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->model('Advancedinvoices');
		$product_id = $this->input->post('product_id');
		//$product_info = $CI->Advancedinvoices->retrieve_product_data($product_id);
		//$product_stock_check = $this->product_stock_check($product_id);

		$product_info = $CI->Advancedinvoices->get_total_product($product_id);
		echo json_encode($product_info);
	}
       // Move to main invoice
        public function move_to_invoice_data($invoice_id)
        {
               $CI =& get_instance();
	       $this->auth->check_admin_auth();
               $CI->load->library('ladvancedinvoice');
	       $CI->load->model('Advancedinvoices'); 
               $invouce_info = $CI->Advancedinvoices->retrieve_advancedinvoice_data($invoice_id);
                
               if(count($invouce_info)){
                    foreach ($invouce_info as $row) {
			 $data_details[] = $row;
		    }

               }	     	

               $advancedinvoice_id = $CI->Advancedinvoices->advancedinvoice_to_main_invoice_entry($data_details);
               if($advancedinvoice_id){
                    $CI->Advancedinvoices->delete_advancedinvoice($invoice_id);
               }   
               $this->session->set_userdata(array('message'=> 'Advanced invoice is successfully moved to main invoice'));
               $content = $CI->ladvancedinvoice->advancedinvoice_list();
 	       $this->template->full_admin_html_view($content);
    	       return true;	         
               

        }
       
	// product_delete
	public function advancedinvoice_delete()
	{	
		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->model('Advancedinvoices');
		$advancedinvoice_id =  $_POST['advancedinvoice_id'];
		$CI->Advancedinvoices->delete_advancedinvoice($advancedinvoice_id);
		$this->session->set_userdata(array('message'=>display('successfully_delete')));
		return true;	
	}
	//AJAX INVOICE STOCKs
	public function product_stock_check($product_id)
	{
		$CI =& get_instance();
		$this->auth->check_admin_auth();
		$CI->load->model('Advancedinvoices');
		//$product_id =  $this->input->post('product_id');

		$purchase_stocks = $CI->Advancedinvoices->get_total_purchase_item($product_id);	
		$total_purchase = 0;		
		if(!empty($purchase_stocks)){	
			foreach($purchase_stocks as $k=>$v){
				$total_purchase = ($total_purchase + $purchase_stocks[$k]['quantity']);
			}
		}
		$sales_stocks = $CI->Advancedinvoices->get_total_sales_item($product_id);
		$total_sales = 0;	
		if(!empty($sales_stocks)){	
			foreach($sales_stocks as $k=>$v){
				$total_sales = ($total_sales + $sales_stocks[$k]['quantity']);
			}
		}
		
		$final_total = ($total_purchase - $total_sales);
		return $final_total ;
	}

	//This function is used to Generate Key
	public function generator($lenth)
	{
		$number=array("1","2","3","4","5","6","7","8","9");
	
		for($i=0; $i<$lenth; $i++)
		{
			$rand_value=rand(0,8);
			$rand_number=$number["$rand_value"];
		
			if(empty($con))
			{ 
			$con=$rand_number;
			}
			else
			{
			$con="$con"."$rand_number";}
		}
		return $con;
	}

    
}