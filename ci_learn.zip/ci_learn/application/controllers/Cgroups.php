<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Cgroups extends CI_Controller {
	function __construct() {
      parent::__construct();
	  $this->load->library('lgroups');
	  $this->load->library('auth');
	  $this->load->library('session');
	  $this->load->model('Groups');
	  $this->auth->check_admin_auth();
	  $this->template->current_menu = 'groups';

	   if ($this->session->userdata('user_type') == '2') {
            $this->session->set_userdata(array('error_message'=>display('you_are_not_access_this_part')));
            redirect('Admin_dashboard');
        }
    }
	
	public function index()
	{
		$data=array('title'=> 'Add User Group');
        $content = $this->parser->parse('groups/new_group',$data,true);
		$this->template->full_admin_html_view($content);
	}
	#================Add new group==============#
        public function permissions($id)
	{ 

	    $CI =& get_instance();
	    $CI->load->model('Groups');
	    $permission_list = $CI->Groups->get_group_permissions($id);

            $i=0;
	    if(!empty($permission_list)){		
		foreach($permission_list as $k=>$v){$i++;
		   $permission_list[$k]['sl']=$i;
		}
	    }
   	   $data = array(
		'id' => $id,
                'title' => 'User Groups',
		'p' => $permission_list
	    );            
	    $content = $CI->parser->parse('groups/permissions',$data,true);
            $this->template->full_admin_html_view($content); 
	    
	}
        public function create_permissions()
	{ 

	    $CI =& get_instance();
	    $CI->load->model('Groups');

	    
   	   $data = array(
                'group_id' => $this->input->post('id'),
                'invoice-index' => $this->input->post('invoice-index'),
                'invoice-add' => $this->input->post('invoice-add'),
                'invoice-edit' => $this->input->post('invoice-edit'),
                'invoice-delete' => $this->input->post('invoice-delete'),
                'advancedinvoice-index' => $this->input->post('advancedinvoice-index'),
                'advancedinvoice-add' => $this->input->post('advancedinvoice-add'),
                'advancedinvoice-edit' => $this->input->post('advancedinvoice-edit'),
                'advancedinvoice-delete' => $this->input->post('advancedinvoice-delete'),
                'pos-invoice' => $this->input->post('pos-invoice'),
                'product-index' => $this->input->post('product-index'),
                'product-add' => $this->input->post('product-add'),
                'product-edit' => $this->input->post('product-edit'),
                'product-delete' => $this->input->post('product-delete'),
                'customer-index' => $this->input->post('customer-index'),
                'customer-add' => $this->input->post('customer-add'),
                'customer-edit' => $this->input->post('customer-edit'),
                'customer-delete' => $this->input->post('customer-delete'),
                'customer-credit' => $this->input->post('customer-credit'),
                'customer-paid' => $this->input->post('customer-paid'),
                'category-index' => $this->input->post('category-index'),
                'category-add' => $this->input->post('category-add'),
                'category-edit' => $this->input->post('category-edit'),
                'category-delete' => $this->input->post('category-delete'),
                'supplier-index' => $this->input->post('supplier-index'),
                'supplier-add' => $this->input->post('supplier-add'),
                'supplier-edit' => $this->input->post('supplier-edit'),
                'supplier-delete' => $this->input->post('supplier-delete'),
                'purchase-index' => $this->input->post('purchase-index'),
                'purchase-add' => $this->input->post('purchase-add'),
                'purchase-edit' => $this->input->post('purchase-edit'),
                'purchase-delete' => $this->input->post('purchase-delete'),
                'stock-report' => $this->input->post('stock-report'),
                'search-customer' => $this->input->post('search-customer'),
                'search-invoice' => $this->input->post('search-invoice'),
                'search-purchase' => $this->input->post('search-purchase'),
                'accounts-add' => $this->input->post('accounts-add'),
                'accounts-edit' => $this->input->post('accounts-edit'),
                'accounts-index' => $this->input->post('accounts-index'),
                'accounts-income' => $this->input->post('accounts-income'),
                'accounts-expense' => $this->input->post('accounts-expense'),
                'accounts-tax-index' => $this->input->post('accounts-tax-index'),
                'accounts-tax-add' => $this->input->post('accounts-tax-add'),
                'accounts-tax-edit' => $this->input->post('accounts-tax-edit'),
                'accounts-tax-delete' => $this->input->post('accounts-tax-delete'),
                'accounts-summery' => $this->input->post('accounts-summery'),
                'accounts-cheque-manager' => $this->input->post('accounts-cheque-manager'),
                'accounts-closing' => $this->input->post('accounts-closing'),
                'accounts-closing-report' => $this->input->post('accounts-closing-report'),
                'reports-index' => $this->input->post('reports-index'),
                'reports-sales' => $this->input->post('reports-sales'),
                'reports-purchase' => $this->input->post('reports-purchase'),
                'reports-sales-product-wise' => $this->input->post('reports-sales-product-wise'),
                'reports-profit' => $this->input->post('reports-profit'),
                'bank-index' => $this->input->post('bank-index'),
                'bank-add' => $this->input->post('bank-add'),
                'bank-edit' => $this->input->post('bank-edit'),
                'bank-delete' => $this->input->post('bank-delete'),              
            );            
         
	    $pt = $CI->Groups->get_group_permissions($this->input->post('id'));
            if($pt){
                $content = $this->Groups->permission_update_by_id($this->input->post('id'),$data);
                $this->session->set_userdata(array('message'=>display('successfully_updated')));                             
  	        
	        $groupList = $CI->parser->parse('groups/permissions',$data,true);  
            }else{
                $invoice_id = $this->Groups->permission_entry($data);
   	        $this->session->set_userdata(array('message'=>display('successfully_added')));	
	        $groupList = $CI->parser->parse('groups/permissions',$data,true);
            } 
           redirect(base_url('Cgroups/permissions/'.$this->input->post('id')));exit;
           
        
        }
	public function add_new_group()
	{ 
	    $CI =& get_instance();
	    $CI->load->model('Groups');
            $group_list = $CI->Groups->get_group_by_name($this->input->post('group_name'));
 
            if($group_list){
	         $this->session->set_userdata(array('message'=>'Group Name already created. Please try other.'));		
		 redirect(base_url('Cgroups/index'));exit;
	     }else{	
		$data = array(
			'name'	=>	$this->input->post('group_name'),
			'description'	=>  $this->input->post('group_description')		
		);
		$invoice_id = $this->Groups->group_entry( $data );
		$this->session->set_userdata(array('message'=>display('successfully_added')));		
		redirect(base_url('Cgroups/group_list'));exit;
	    }
	}
	#==============Bank list============#
	public function group_list()
	{
             $content = $this->lgroups->group_list( );
	     $this->template->full_admin_html_view($content);
	}
        public function permission_list($id)
	{
             $content = $this->lgroups->permission_list($id);
	     $this->template->full_admin_html_view($content);
	}
	#=============Bank edit==============#
	public function edit_group($group_id)
	{
        $content = $this->lgroups->group_show_by_id($group_id);
		$this->template->full_admin_html_view($content);
	}
	#============Update Bank=============#
	public function update_group($group_id)
	{
            $CI =& get_instance();
	    $CI->load->model('Groups');
            $group_list = $CI->Groups->get_group_by_name($this->input->post('group_name'));
 
            if($group_list){
	         $this->session->set_userdata(array('message'=>'Group Name already created. Please try other.'));		
		 redirect(base_url('Cgroups/index'));exit;
	     }else{
                 $content = $this->lgroups->group_update_by_id($group_id);
                 $this->session->set_userdata(array('message'=>display('successfully_updated')));
                 redirect('Cgroups/group_list');
             }
	}
	
}