<!-- Profit Report Start -->
<div class="content-wrapper">
	<section class="content-header">
	    <div class="header-icon">
	        <i class="pe-7s-note2"></i>
	    </div>
	    <div class="header-title">
	        <h1><?php echo 'With or Without Tax Report' ?></h1>
	        <small><?php echo 'With or Without Tax Report'?></small>
	        <ol class="breadcrumb">
	            <li><a href="#"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
	            <li><a href="#"><?php echo display('report') ?></a></li>
	            <li class="active"><?php echo 'With or Without Tax Report' ?></li>
	        </ol>
	    </div>
	</section>

	<section class="content">
		<!-- Profit report -->
		

		<div class="row">
		    <div class="col-sm-12">
		        <div class="panel panel-bd lobidrag">
		            <div class="panel-heading">
		                <div class="panel-title">
		                    <h4><?php echo 'With or Without Tax Report' ?></h4>
		                </div>
		            </div>
		            <div class="panel-body">
		                <div class="table-responsive">
		                    <table id="dataTableExample2" class="table table-bordered table-striped table-hover">
		                        <thead>
									<tr>
										<th><?php echo display('sales_date') ?></th>
										<th><?php echo display('invoice_no') ?></th>
										<th><?php echo 'With Tax Amount' ?></th>
										<th><?php echo 'Without Tax Amount' ?></th>
									</tr>
								</thead>
								<tbody>
								<?php
									if($total_profit_report) {
								?>
									{total_profit_report}
										<tr>
											<td>{prchse_date}</td>
											<td>
												<a href="<?php echo base_url().'Cinvoice/invoice_inserted_data/{invoice_id}'; ?>">
													{invoice}
												</a>
											</td>
											<td style="text-align: right;">
											<?php echo (($position==0)?"$currency {with_tax}":"{with_tax} $currency") ?>
											</td>
											<td style="text-align: right;"><?php echo (($position==0)?"$currency {without_tax}":"{without_tax} $currency") ?></td>
										</tr>
									{/total_profit_report}
								<?php
									}
								?>
								</tbody>
								<tfoot>
									<tr>
										<td colspan="3" align="right" style="text-align:right;font-size:14px !Important">&nbsp; <b><?php echo (($position==0)?"$currency {total_with_tax_ammount}":"{total_with_tax_ammount} $currency") ?> </b></td>
										<td style="text-align: right;"><b><?php echo (($position==0)?"$currency {total_without_tax_ammount}":"{total_without_tax_ammount} $currency") ?></b></td>
									</tr>
								</tfoot>
		                    </table>
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
	</section>
</div>
 <!-- Profit Report End -->