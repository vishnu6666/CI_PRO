<!-- Purchase Report Start -->
<div class="content-wrapper">
	<section class="content-header">
	    <div class="header-icon">
	        <i class="pe-7s-note2"></i>
	    </div>
	    <div class="header-title">
	        <h1>Transfer Product Report</h1>
	        <small>Transfer Product Report</small>
	        <ol class="breadcrumb">
	            <li><a href="#"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
	            <li><a href="#"><?php echo display('report') ?></a></li>
	            <li class="active">Transfer Product Report</li>
	        </ol>
	    </div>
	</section>

	<section class="content">
		<!-- Purchase report -->
		
		<div class="row">
		    <div class="col-sm-12">
		        <div class="panel panel-bd lobidrag">
		            <div class="panel-heading">
		                <div class="panel-title">
		                    <h4>Transfer Product Report</h4>
		                </div>
		            </div>
		            <div class="panel-body">
		                <div class="table-responsive">
		                    <table id="dataTableExample2" class="table table-bordered table-striped table-hover">
		                        <thead>
									<tr>
										<th>Transfer Date</th>
										<th>Product Name</th>
										<th>Company Name</th>
										<th>Total Quantity</th>
										
									</tr>
								</thead>
								<tbody>
								<?php
									if($transfer_report) {
								?>
									{transfer_report}
										<tr>
											<td>{transfer_date}</td>
											<td>{product_name}</td>
											<td>{company_name}</td>
											<td style="text-align: right;">{totalQnty}</td>
										</tr>
									{/transfer_report}
								<?php
									}
								?>
								</tbody>
								
		                    </table>
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
	</section>
</div>
 <!-- Purchase Report End -->