<!-- Sales Report Start -->
<div class="content-wrapper">
	<section class="content-header">
	    <div class="header-icon">
	        <i class="pe-7s-note2"></i>
	    </div>
	    <div class="header-title">
	        <h1><?php echo 'Expiry Medicine Report' ?></h1>
	        <small><?php echo 'Expiry Medicine Report' ?></small>
	        <ol class="breadcrumb">
	            <li><a href="index.html"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
	            <li><a href="#"><?php echo display('report') ?></a></li>
	            <li class="active"><?php echo 'Expiry Medicine Report' ?></li>
	        </ol>
	    </div>
	</section>

	<section class="content">
		<!-- Sales report -->
		

		<div class="row">
		    <div class="col-sm-12">
		        <div class="panel panel-bd lobidrag">
		            <div class="panel-heading">
		                <div class="panel-title">
		                    <h4><?php echo 'Expiry Medicine Report' ?> </h4>
		                </div>
		            </div>
		            <div class="panel-body">
		                <div class="table-responsive">
		                    <table id="dataTableExample2" class="table table-bordered table-striped table-hover">
		                        <thead>
		                            <tr>
		                                <th><?php echo 'Expiry Date' ?></th>
										<th><?php echo 'Product Name' ?></th>									
										<th><?php echo 'Total Quantity' ?></th>
										<th><?php echo display('total_amount') ?></th>
		                            </tr>
		                        </thead>
		                        <tfoot>
									<tr>
										<td colspan="3" style="text-align: right;"><b><?php echo 'Total Amount' ?></b></td>
										<td style="text-align: right;"><b><?php echo (($position==0)?"$currency {sales_amount}":"{sales_amount} $currency") ?></b></td>
									</tr>
								</tfoot>
		                        <tbody>
		                        <?php
		                        	if ($medicine_report) {
		                        ?>
		                            {medicine_report}
									<tr>
										<td>{expire_date}</td>
										<td>{product_name}</td>
										<td>{totalQnty}</td>
										<td>{totalAmt}</td>										
									</tr>
								{/medicine_report}
								<?php
									}
								?>
		                        </tbody>
		                    </table>
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
	</section>
</div>
 <!-- Sales Report End -->