<!-- Customer type change by javascript start -->
<script type="text/javascript">
    //Customer old/new    
    function add_customer_fund(status)
    {
	    if(status=="payment_from_1"){
	       
	        document.getElementById("payment_from_1").style.display="block";
	        document.getElementById("myRadioButton_2").checked = false;
	        document.getElementById("myRadioButton_1").checked = true;
	    }
	    else{
	        document.getElementById("payment_from_1").style.display="none";
	       
	        document.getElementById("myRadioButton_2").checked = false;
	        document.getElementById("myRadioButton_1").checked = true;
	    }
    }

</script>
<!-- Add new invoice start -->
<style>
	#bank_info_hide
	{
		display:none;
	}
    #payment_from_2
    {
        display:none;
    }
</style>
<div class="content-wrapper">
	<section class="content-header">
	    <div class="header-icon">
	        <i class="pe-7s-note2"></i>
	    </div>
	    <div class="header-title">
	        <h1><?php echo display('customer_ledger') ?></h1>
	        <small><?php echo display('manage_customer_ledger') ?></small>
	        <ol class="breadcrumb">
	            <li><a href="#"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
	            <li><a href="#"><?php echo display('customer') ?></a></li>
	            <li class="active"><?php echo display('customer_ledger') ?></li>
	        </ol>
	    </div>
	</section>

	<!-- Customer information -->
	<section class="content">
		<!-- Alert Message -->
	    <?php
	        $message = $this->session->userdata('message');
	        if (isset($message)) {
	    ?>
	    <div class="alert alert-info alert-dismissable">
	        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
	        <?php echo $message ?>                    
	    </div>
	    <?php 
	        $this->session->unset_userdata('message');
	        }
	        $error_message = $this->session->userdata('error_message');
	        if (isset($error_message)) {
	    ?>
	    <div class="alert alert-danger alert-dismissable">
	        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
	        <?php echo $error_message ?>                    
	    </div>
	    <?php 
	        $this->session->unset_userdata('error_message');
	        }
	    ?>

		<div class="row">
		    <div class="col-sm-12">
		        <div class="panel panel-bd lobidrag">
		            <div class="panel-heading">
		                <div class="panel-title">
		                    <h4><?php echo display('customer_information') ?></h4>
		                </div>
		            </div>
		            <div class="panel-body">
	  					<div style="float:left">
							{company_info}
							<h5><u> {company_name}</u></h5>
							{/company_info}
							<?php echo display('customer_name') ?> : {customer_name} <br>
							<?php echo display('customer_address') ?> : {customer_address}<br>
							<?php echo display('mobile') ?> : {customer_mobile}
						</div>
						<div style="float:right;margin-right:100px">
							<table class="table table-striped table-condensed table-bordered">
								<tr><td> <?php echo display('debit_ammount') ?> </td> <td style="text-align:right !Important;margin-right:20px"> <?php echo (($position==0)?"$currency {total_debit}":"{total_debit} $currency")?></td> </tr>
								<tr><td><?php echo display('credit_ammount');?></td> <td style="text-align:right !Important;margin-right:20px"> <?php echo (($position==0)?"$currency {total_credit}":"{total_credit} $currency") ?></td> </tr>
								<tr><td><?php echo display('balance_ammount');?> </td> <td style="text-align:right !Important;margin-right:20px"> <?php echo (($position==0)?"$currency {total_balance}":"{total_balance} $currency")?></td> </tr>
								
								
							</table>
							 <input id="myRadioButton_1" type="button" onClick="add_customer_fund('payment_from_1')" id="myRadioButton_1" class="btn btn-success checkbox_account" name="customer_confirm" checked="checked" value="<?php echo 'Add Fund Value' ?>">
							 
							 <?php echo form_open_multipart('Ccustomer/customer_add_fund',array('class' => 'form-vertical', 'id' => 'insert_invoice','name' => 'insert_invoice'))?>
							 
							 <input type="hidden" value="{customer_id}" name="customer_id">
							  <table class="table table-striped table-condensed table-bordered" id="payment_from_1"  style="display:none;">
								<tr><td>&nbsp; </td> </tr>
								<tr><td>Fund Value : 
                                      </td> </tr>
								
								<tr><td><input type="text"   name="previous_balance" class="form-control" placeholder='Fund Value' id="previous_balance" /></td> </tr>
									<tr><td><input type="submit" value="Submit"  name="submit" class="btn btn-success checkbox_account" id="submit" /></td> </tr>
								
								
							</table>
                              
                           <?php echo form_close()?>
							
						</div>
						
		            </div>
		        </div>
		    </div>
		</div>

		<!-- Manage Customer -->
		<div class="row">
		    <div class="col-sm-12">
		        <div class="panel panel-bd lobidrag">
		            <div class="panel-heading">
		                <div class="panel-title">
		                    <h4><?php echo display('customer_ledger') ?></h4>
		                </div>
		            </div>
		            <div class="panel-body">
		                <div class="table-responsive">
		                    <table id="dataTableExample2" class="table table-bordered table-striped table-hover">
								<thead>
									<tr>
										<th><?php echo display('date') ?></th>
										<th><?php echo display('invoice_no') ?></th>
										<th><?php echo display('receipt_no') ?></th>
										<th><?php echo display('description') ?></th>
										<th style="text-align:right !Important;margin-right:20px"><?php echo display('debit') ?></th>
										<th style="text-align:right !Important;margin-right:20px"><?php echo display('credit') ?></th>
										<th style="text-align:right !Important;margin-right:20px"><?php echo display('balance') ?></th>
									</tr>
								</thead>
								<tbody>
								<?php
									if($ledger){
								?>
								{ledger}
									<tr>
										<td>{final_date}</td>
										<td>
											<a href="<?php echo base_url().'Cinvoice/invoice_inserted_data/{invoice_no}'; ?>">
												{invoice_no}
											</a>
										</td>
										<td>
											{receipt_no}
										</td>
										<td>{description}</td>
										<td style="text-align:right;"> 

										<?php
										echo (($position==0)?"$currency {debit}":"{debit} $currency")?>
											
										</td>
										<td style="text-align:right;"> <?php echo (($position==0)?"$currency {credit}":"{credit} $currency") ?></td>
										<td style="text-align:right;"> <?php echo (($position==0)?"$currency {balance}":"{balance} $currency") ?></td>
									</tr>
								{/ledger}
								<?php
									}
								?>
								</tbody>
		                    </table>
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
	</section>
</div>
<!-- Customer Ledger End  -->