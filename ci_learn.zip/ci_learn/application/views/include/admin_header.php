<?php
    $CI =& get_instance();
    $CI->load->model('Web_settings');
    $CI->load->model('Users');
	$CI->load->model('Groups'); 
    $Web_settings = $CI->Web_settings->retrieve_setting_editdata();
    $users = $CI->Users->profile_edit_data();
    $uid= $this->session->userdata('user_id'); 
    $gid= $this->session->userdata('group_id'); 
    $cid= $this->session->userdata('company_id'); 
    $gp = $CI->Groups->get_group_by_name_id('admin', $uid, $gid);
    if($gp[0]["name"]=='admin'){
        $Admin=true;
    }else{
       $Admin=false;
    }
?>
<!-- Admin header end -->
<header class="main-header"> 
    <a href="<?php echo base_url()?>" class="logo"> <!-- Logo -->
        <span class="logo-mini">
            <!--<b>A</b>BD-->
            <img src="<?php if (isset($Web_settings[0]['favicon'])) {
               echo $Web_settings[0]['favicon']; }?>" alt="">
        </span>
        
    </a>
    <!-- Header Navbar -->
    <nav class="navbar navbar-static-top">
        <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button"> <!-- Sidebar toggle button-->
            <span class="sr-only">Toggle navigation</span>
            <span class="pe-7s-keypad"></span>
        </a>
        <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
                <!-- settings -->
                <li class="dropdown dropdown-user">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"> <i class="pe-7s-settings"></i></a>
                    <ul class="dropdown-menu">
                        <li><a href="<?php echo base_url('Admin_dashboard/edit_profile')?>"><i class="pe-7s-users"></i><?php echo display('user_profile') ?></a></li>
                        <li><a href="<?php echo base_url('Admin_dashboard/change_password_form')?>"><i class="pe-7s-settings"></i><?php echo display('change_password') ?></a></li>
                        <li><a href="<?php echo base_url('Admin_dashboard/logout')?>"><i class="pe-7s-key"></i><?php echo display('logout') ?></a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>
</header>

<aside class="main-sidebar">
	<!-- sidebar -->
	<div class="sidebar">
            <?php if($Admin){ ?>
	    <!-- Sidebar user panel -->
	    <div class="user-panel text-center">
	      
	        <div class="info">
	            <p><?php echo $this->session->userdata('user_name')?></p>
	            <a href="#"><i class="fa fa-circle text-success"></i> <?php echo display('online') ?><?php print_r($Admin); ?></a>
	        </div>
	    </div>
	    <!-- sidebar menu -->
	    <ul class="sidebar-menu">

	        <li class="<?php if ($this->uri->segment('1') == ("")) { echo "active";}else{ echo " ";}?>">
	            <a href="<?php echo base_url()?>"><i class="ti-dashboard"></i> <span><?php echo display('dashboard') ?></span>
	                <span class="pull-right-container">
	                    <span class="label label-success pull-right"></span>
	                </span>
	            </a>
	        </li>

            <!-- Invoice menu start -->
            <li class="treeview <?php if ($this->uri->segment('1') == ("Cinvoice")) { echo "active";}else{ echo " ";}?>">
                <a href="#">
                    <i class="ti-layout-accordion-list"></i><span><?php echo display('invoice') ?></span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo base_url('Cinvoice')?>"><?php echo 'Invoice' ?></a></li>                    
                    <li><a href="<?php echo base_url('Cinvoice/manage_invoice')?>"><?php echo 'Manage Invoice' ?></a></li>
                    <li><a href="<?php echo base_url('Cadvancedinvoice')?>"><?php echo 'Add Tax Inovice' ?></a></li>
                    <li><a href="<?php echo base_url('Cadvancedinvoice/manage_advancedinvoice')?>"><?php echo 'Manage Tax Inovice'; ?></a></li>
					
                    
                </ul>
            </li>
            <!-- Invoice menu end -->

            <!-- Product menu start -->
            <li class="treeview <?php if ($this->uri->segment('1') == ("Cproduct") || $this->uri->segment('1') == ("Cqrcode") || $this->uri->segment('1') == ("Cbarcode")) { echo "active";}else{ echo " ";}?>">
                <a href="#">
                    <i class="ti-bag"></i><span><?php echo display('product') ?></span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo base_url('Cproduct')?>"><?php echo display('add_product') ?></a></li>
                    <li><a href="<?php echo base_url('Cproduct/manage_product')?>"><?php echo display('manage_product') ?></a></li>
					<!--  <li><a href="<?php echo base_url('Cproduct/add_product_mapping')?>"><?php echo 'Add Product Mapping'; ?></a></li>
                    <li><a href="<?php echo base_url('Cproduct/manage_product_mapping')?>"><?php echo 'Manage Product Mapping' ?></a></li> -->
                     <li><a href="<?php echo base_url('Cproduct/add_manufacture')?>"><?php echo 'Add Manufacture'; ?></a></li>
                    <li><a href="<?php echo base_url('Cproduct/manage_manufacture')?>"><?php echo 'Manage Manufacture' ?></a></li>
					<li><a href="<?php echo base_url('Cproduct/transfer_products')?>"><?php echo 'Transfer Product' ?></a></li> 
					<li><a href="<?php echo base_url('Cproduct/manage_product_transfer')?>"><?php echo 'Manage Transfer Product' ?></a></li> 
                    <?php 
                    if ($this->uri->segment(2) == "product_details") {
                    ?>
                    <li><a href="<?php echo base_url($product_statement)?>"><?php echo display('product_statement') ?></a></li>
                    <?php
                    }?>
                </ul>
            </li>
            <!-- Product menu end -->

 <!-- service menu start -->
            <li class="treeview <?php if ($this->uri->segment('1') == ("Cservices") || $this->uri->segment('1') == ("Cqrcode") || $this->uri->segment('1') == ("Cbarcode")) { echo "active";}else{ echo " ";}?>">
                <a href="#">
                    <i class="ti-bag"></i><span><?php echo "Service" ?></span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo base_url('Cservices')?>"><?php echo " Add Service" ?></a></li>
                    <li><a href="<?php echo base_url('Cservices/manage_services')?>"><?php echo "Manage Service" ?></a></li>
                    <!--  <li><a href="<?php echo base_url('Cservices/add_product_mapping')?>"><?php echo 'Add Product Mapping'; ?></a></li>
                    <li><a href="<?php echo base_url('Cservices/manage_product_mapping')?>"><?php echo 'Manage Product Mapping' ?></a></li> -->
                    <!--  <li><a href="<?php echo base_url('Cservices/add_manufacture')?>"><?php echo 'Add Manufacture'; ?></a></li>
                    <li><a href="<?php echo base_url('Cservices/manage_manufacture')?>"><?php echo 'Manage Manufacture' ?></a></li>
                    <li><a href="<?php echo base_url('Cservices/transfer_products')?>"><?php echo 'Transfer Product' ?></a></li> 
                    <li><a href="<?php echo base_url('Cservices/manage_product_transfer')?>"><?php echo 'Manage Transfer Product' ?></a></li> 
                    <?php 
                    if ($this->uri->segment(2) == "product_details") {
                    ?>
                    <li><a href="<?php echo base_url($product_statement)?>"><?php echo display('product_statement') ?></a></li>
                    <?php
                    }?> -->
                </ul>
            </li>
            <!-- service menu end -->



            <!-- Customer menu start -->
            <li class="treeview <?php if ($this->uri->segment('1') == ("Ccustomer")) { echo "active";}else{ echo " ";}?>">
                <a href="#">
                    <i class="fa fa-handshake-o"></i><span><?php echo display('customer') ?></span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo base_url('Ccustomer')?>"><?php echo display('add_customer') ?></a></li>
                    <li><a href="<?php echo base_url('Ccustomer/manage_customer')?>"><?php echo display('manage_customer') ?></a></li>
                    <li><a href="<?php echo base_url('Ccustomer/credit_customer')?>"><?php echo display('credit_customer') ?></a></li>
                    <li><a href="<?php echo base_url('Ccustomer/paid_customer')?>"><?php echo display('paid_customer') ?></a></li>
                </ul>
            </li>
            <!-- Customer menu end -->

            <!-- Category menu start -->
            <li class="treeview <?php if ($this->uri->segment('1') == ("Ccategory")) { echo "active";}else{ echo " ";}?>">
                <a href="#">
                    <i class="ti-tag"></i><span><?php echo display('category') ?></span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo base_url('Ccategory')?>"><?php echo display('add_category') ?></a></li>
                    <li><a href="<?php echo base_url('Ccategory/manage_category')?>"><?php echo display('manage_category') ?></a></li>
                </ul>
            </li>
            <!-- Category menu end -->

	        <!-- Supplier menu start -->
	        <li class="treeview <?php if ($this->uri->segment('1') == ("Csupplier")) { echo "active";}else{ echo " ";}?>">
                <a href="#">
                    <i class="ti-user"></i><span><?php echo display('supplier') ?></span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo base_url('Csupplier')?>"><?php echo display('add_supplier') ?></a></li>
                    <li><a href="<?php echo base_url('Csupplier/manage_supplier')?>"><?php echo display('manage_supplier') ?></a></li>
                    <?php 
                    if (isset($supplier_ledger)) {
                    ?>
                    <li><a href="<?php echo base_url($supplier_ledger)?>"><?php echo display('supplier_ledger') ?></a></li>
                    <li><a href="<?php echo base_url($supplier_sales_details)?>"><?php echo display('supplier_sales_details') ?></a></li>
                    <li><a href="<?php echo base_url($supplier_sales_summary)?>"><?php echo display('supplier_sales_summary') ?></a></li>
                    <li><a href="<?php echo base_url($sales_payment_actual)?>"><?php echo display('supplier_payment_actual') ?></a></li>
                    <?php
                    }?>
                </ul>
            </li>
            <!-- Supplier menu end -->

            <!-- Purchase menu start -->
	        <li class="treeview <?php if ($this->uri->segment('1') == ("Cpurchase")) { echo "active";}else{ echo " ";}?>">
                <a href="#">
                    <i class="ti-shopping-cart"></i><span><?php echo display('purchase') ?></span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo base_url('Cpurchase')?>"><?php echo display('add_purchase') ?></a></li>
                    <li><a href="<?php echo base_url('Cpurchase/manage_purchase')?>"><?php echo display('manage_purchase') ?></a></li>
					<li><a href="<?php echo base_url('Cpurchase/add_purchase_return_form')?>"><?php echo 'Add Purchase Return' ?></a></li>
					<li><a href="<?php echo base_url('Cpurchase/manage_purchase_return')?>"><?php echo 'Manage Purchase Return Order' ?></a></li>
                </ul>
            </li>
            <!-- Purchase menu end -->

            <!-- Stock menu start -->
            <li class="treeview <?php if ($this->uri->segment('1') == ("Creport")) { echo "active";}else{ echo " ";}?>">
                <a href="#">
                    <i class="ti-bar-chart"></i><span><?php echo display('stock') ?></span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo base_url('Creport')?>"><?php echo display('stock_report') ?></a></li>
                </ul>
            </li>
            <!-- Stock menu end -->

            
            <!-- Search menu start -->
            <li class="treeview <?php if ($this->uri->segment('1') == ("Csearch")) { echo "active";}else{ echo " ";}?>">
                <a href="#">
                    <i class="ti-search"></i><span><?php echo display('search') ?></span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo base_url('Csearch/customer')?>"><?php echo display('customer') ?> </a></li>
                    <li><a href="<?php echo base_url('Csearch/invoice')?>"><?php echo display('invoice') ?> </a></li>
                    <li><a href="<?php echo base_url('Csearch/purchase')?>"><?php echo display('purchase') ?> </a></li>
					
                </ul>
            </li>
            <!-- Search menu end -->

            <?php
                if ($this->session->userdata('user_type') == '1') {
            ?>

            <!-- Accounts menu start -->
            <li class="treeview <?php if ($this->uri->segment('1') == ("Caccounts") || $this->uri->segment('2') == ("table_create") || $this->uri->segment('2') == ("table_list") || $this->uri->segment('2') == ("table_edit")) { echo "active";}else{ echo " ";}?>">
                <a href="#">
                    <i class="ti-pencil-alt"></i><span><?php echo display('accounts') ?></span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo base_url('Csettings/table_create/')?>"><?php echo display('create_accounts') ?> </a></li>
                    <li><a href="<?php echo base_url('Csettings/table_list/')?>"><?php echo display('manage_accounts') ?> </a></li>
                    <li><a href="<?php echo base_url('Caccounts')?>"><?php echo display('income') ?></a></li>
                    <li><a href="<?php echo base_url('Caccounts/outflow/')?>"><?php echo display('expense') ?></a></li>
                    <li><a href="<?php echo base_url('Caccounts/add_tax/')?>"><?php echo display('add_tax') ?></a></li>
                    <li><a href="<?php echo base_url('Caccounts/manage_tax/')?>"><?php echo display('manage_tax') ?></a></li>
                    <li><a href="<?php echo base_url('Caccounts/summary/')?>"><?php echo display('accounts_summary') ?></a></li>
                    <li><a href="<?php echo base_url('Caccounts/cheque_manager/')?>"><?php echo display('cheque_manager') ?></a></li>
                    <li><a href="<?php echo base_url('Caccounts/closing/')?>"><?php echo display('closing') ?></a></li>
                    <li><a href="<?php echo base_url('Caccounts/closing_report/')?>"><?php echo display('closing_report') ?></a></li>
                </ul>
            </li>
            <!-- Accounts menu end -->

            <!-- Report menu start -->
            <li class="treeview <?php if ($this->uri->segment('2') == ("all_report") || $this->uri->segment('2') == ("todays_sales_report") || $this->uri->segment('2') == ("todays_purchase_report") || $this->uri->segment('2') == ("product_sales_reports_date_wise") || $this->uri->segment('2') == ("total_profit_report") ) { echo "active";}else{ echo " ";}?>">
                <a href="#">
                    <i class="ti-book"></i><span><?php echo display('report') ?></span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo base_url('Admin_dashboard/all_report')?>"><?php echo display('todays_report') ?></a></li>
                    <li><a href="<?php echo base_url('Admin_dashboard/todays_sales_report')?>"><?php echo display('sales_report') ?></a></li>
					<li><a href="<?php echo base_url('Admin_dashboard/todays_bulk_sales_report')?>">Bulk <?php echo display('sales_report') ?></a></li>
                    <li><a href="<?php echo base_url('Admin_dashboard/todays_purchase_report')?>"><?php echo display('purchase_report') ?></a></li>
                    <li><a href="<?php echo base_url('Admin_dashboard/product_sales_reports_date_wise')?>"><?php echo display('sales_report_product_wise') ?></a></li>
                    <li><a href="<?php echo base_url('Admin_dashboard/total_profit_report')?>"><?php echo display('profit_report') ?></a></li>
					<li><a href="<?php echo base_url('Admin_dashboard/daily_cash_report')?>"><?php echo 'Daily Cash Report' ?></a></li>
					<li><a href="<?php echo base_url('Admin_dashboard/transfer_product_report')?>"><?php echo 'Transfer Product Report' ?></a></li>
					
                </ul>
            </li>
            <!-- Report menu end -->

            <!-- Bank menu start -->
            <li class="treeview <?php if ($this->uri->segment('2') == ("index") || $this->uri->segment('2') == ("bank_list")) { echo "active";}else{ echo " ";}?>">
                <a href="#">
                    <i class="ti-briefcase"></i><span>Salary</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo base_url('Csalary/index')?>">Add Salary</a></li>
                    <li><a href="<?php echo base_url('Csalary/manage_salary/')?>">Manage Salary</a></li>
                </ul>
            </li>
            <!-- Bank menu end -->
			
			  <!-- Bank menu start -->
            <li class="treeview <?php if ($this->uri->segment('2') == ("index") || $this->uri->segment('2') == ("bank_list")) { echo "active";}else{ echo " ";}?>">
                <a href="#">
                    <i class="ti-briefcase"></i><span>Bank</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo base_url('Csettings/index')?>"><?php echo display('add_new_bank') ?></a></li>
                    <li><a href="<?php echo base_url('Csettings/bank_list/')?>"><?php echo display('manage_bank') ?></a></li>
                    <li><a href="<?php echo base_url('Csettings/bank_statment/')?>">Bank Statment</a></li>
                </ul>
            </li>
            <!-- Bank menu end -->
			

            <!-- Software Settings menu start -->
            <li class="treeview <?php if ($this->uri->segment('1') == ("Company_setup") || $this->uri->segment('1') == ("User") || $this->uri->segment('1') == ("Cweb_setting") || $this->uri->segment('1') == ("Language") ) { echo "active";}else{ echo " ";}?>">
                <a href="#">
                    <i class="ti-settings"></i><span><?php echo display('web_settings') ?></span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo base_url('Company_setup/manage_company')?>"><?php echo display('manage_company') ?></a></li>         <li><a href="<?php echo base_url('Company_setup/index')?>"><?php echo 'Add Shop'; ?></a></li>           <li><a href="<?php echo base_url('Cgroups/index')?>"><?php echo 'Add User Group'; ?></a></li>
                    <li><a href="<?php echo base_url('Cgroups/group_list/')?>"><?php echo 'Group Permissions'; ?></a></li>
                    <li><a href="<?php echo base_url('User')?>"><?php echo display('add_user') ?></a></li>
                    <li><a href="<?php echo base_url('User/manage_user')?>"><?php echo display('manage_users') ?> </a></li>
                    <li><a href="<?php echo base_url('Language')?>"><?php echo display('language') ?> </a></li>
                    <li><a href="<?php echo base_url('Cweb_setting')?>"><?php echo display('setting') ?> </a></li>
                </ul>
            </li>
            <!-- Software Settings menu end -->
            <?php
                }
            ?>
	    </ul>
          <?php }else{ ?>
           <!-- Sidebar user panel -->
	    <div class="user-panel text-center">
	        <div class="image">
	            <img src="<?php echo $users[0]['logo']?>" class="img-circle" alt="User Image">
	        </div>
	        <div class="info">
	            <p><?php echo $this->session->userdata('user_name')?><?php echo $Admin; ?></p>
	            <a href="#"><i class="fa fa-circle text-success"></i> <?php echo display('online') ?></a>
	        </div>
	    </div>
	    <!-- sidebar menu -->
	    <ul class="sidebar-menu">

	        <li class="<?php if ($this->uri->segment('1') == ("")) { echo "active";}else{ echo " ";}?>">
	            <a href="<?php echo base_url()?>"><i class="ti-dashboard"></i> <span><?php echo display('dashboard') ?></span>
	                <span class="pull-right-container">
	                    <span class="label label-success pull-right"></span>
	                </span>
	            </a>
	        </li>
           <?php if($CI->Groups->checkPermissions($gid, 'invoice-add') || $CI->Groups->checkPermissions($gid, 'invoice-index') || $CI->Groups->checkPermissions($gid, 'advancedinvoice-add') || $CI->Groups->checkPermissions($gid, 'advancedinvoice-index') || $CI->Groups->checkPermissions($gid, 'pos-invoice')){ ?>
            <!-- Invoice menu start -->
            <li class="treeview <?php if ($this->uri->segment('1') == ("Cinvoice")) { echo "active";}else{ echo " ";}?>">
                <a href="#">
                    <i class="ti-layout-accordion-list"></i><span><?php echo display('invoice') ?></span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">			
					
                    <?php if($CI->Groups->checkPermissions($gid, 'invoice-add')){ ?> 
                   <li><a href="<?php echo base_url('Cinvoice')?>"><?php echo 'Invoice' ?></a></li>             
                    <?php } ?> 
                    <?php if($CI->Groups->checkPermissions($gid, 'invoice-index')){ ?>          
                    <li><a href="<?php echo base_url('Cinvoice/manage_invoice')?>"><?php echo 'Manage Invoice' ?></a></li>
                    <?php } ?>
                    <?php if($CI->Groups->checkPermissions($gid, 'advancedinvoice-add')){ ?> 
                   <li><a href="<?php echo base_url('Cadvancedinvoice')?>"><?php echo 'Add Tax Inovice' ?></a></li>
                    <?php } ?> 
                    <?php if($CI->Groups->checkPermissions($gid, 'advancedinvoice-index')){ ?> 
                  <li><a href="<?php echo base_url('Cadvancedinvoice/manage_advancedinvoice')?>"><?php echo 'Manage Tax Inovice'; ?></a></li>
                    <?php } ?>
					
                    
                </ul>
            </li>
            <!-- Invoice menu end -->
           <?php } ?>
            <!-- Product menu start -->
           <?php if($CI->Groups->checkPermissions($gid, 'product-index') || $CI->Groups->checkPermissions($gid, 'product-add') || $CI->Groups->checkPermissions($gid, 'product-edit') || $CI->Groups->checkPermissions($gid, 'product-delete')){ ?>
            <li class="treeview <?php if ($this->uri->segment('1') == ("Cproduct") || $this->uri->segment('1') == ("Cqrcode") || $this->uri->segment('1') == ("Cbarcode")) { echo "active";}else{ echo " ";}?>">
                <a href="#">
                    <i class="ti-bag"></i><span><?php echo display('product') ?></span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <?php if($CI->Groups->checkPermissions($gid, 'product-add')){ ?>  
                    <li><a href="<?php echo base_url('Cproduct')?>"><?php echo display('add_product') ?></a></li>
                      <?php } ?>
                     <?php if($CI->Groups->checkPermissions($gid, 'product-index')){ ?> 
                    <li><a href="<?php echo base_url('Cproduct/manage_product')?>"><?php echo display('manage_product') ?></a></li>
                     <?php } ?>
					  <!-- <li><a href="<?php echo base_url('Cproduct/add_product_mapping')?>"><?php echo 'Add Product Mapping'; ?></a></li>
                    <li><a href="<?php echo base_url('Cproduct/manage_product_mapping')?>"><?php echo 'Manage Product Mapping' ?></a></li> -->
                     <li><a href="<?php echo base_url('Cproduct/add_manufacture')?>"><?php echo 'Add Manufacture'; ?></a></li>
                    <li><a href="<?php echo base_url('Cproduct/manage_manufacture')?>"><?php echo 'Manage Manufacture' ?></a></li>
                    <?php 
                    if ($this->uri->segment(2) == "product_details") {
                    ?>
                    <li><a href="<?php echo base_url($product_statement)?>"><?php echo display('product_statement') ?></a></li>
                    <?php
                    }?>
                </ul>
            </li>
            <!-- Product menu end -->

             <?php } ?>

 <!-- service menu start -->
           <?php if($CI->Groups->checkPermissions($gid, 'product-index') || $CI->Groups->checkPermissions($gid, 'product-add') || $CI->Groups->checkPermissions($gid, 'product-edit') || $CI->Groups->checkPermissions($gid, 'product-delete')){ ?>
            <li class="treeview <?php if ($this->uri->segment('1') == ("Cservices") || $this->uri->segment('1') == ("Cqrcode") || $this->uri->segment('1') == ("Cbarcode")) { echo "active";}else{ echo " ";}?>">
                <a href="#">
                    <i class="ti-bag"></i><span>Service</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <?php if($CI->Groups->checkPermissions($gid, 'service-add')){ ?>  
                    <li><a href="<?php echo base_url('Cservices')?>">Add Service</a></li>
                      <?php } ?>
                     <?php if($CI->Groups->checkPermissions($gid, 'product-index')){ ?> 
                    <li><a href="<?php echo base_url('Cservices/manage_services')?>">Manage Services</a></li>
                     <?php } ?>
                </ul>
            </li>
             <?php } ?>

 <!-- service menu end -->


              <?php if($CI->Groups->checkPermissions($gid, 'customer-index') || $CI->Groups->checkPermissions($gid, 'customer-add') || $CI->Groups->checkPermissions($gid, 'customer-credit') || $CI->Groups->checkPermissions($gid, 'customer-paid')){ ?>
            <li class="treeview <?php if ($this->uri->segment('1') == ("Ccustomer")) { echo "active";}else{ echo " ";}?>">
                <a href="#">
                    <i class="fa fa-handshake-o"></i><span><?php echo display('customer') ?></span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <?php if($CI->Groups->checkPermissions($gid, 'customer-add')){ ?>   
                    <li><a href="<?php echo base_url('Ccustomer')?>"><?php echo display('add_customer') ?></a></li>
                    <?php } ?>
                    <?php if($CI->Groups->checkPermissions($gid, 'customer-index')){ ?>   
                    <li><a href="<?php echo base_url('Ccustomer/manage_customer')?>"><?php echo display('manage_customer') ?></a></li>         <?php } ?>
                    <?php if($CI->Groups->checkPermissions($gid, 'customer-credit')){ ?>   
                    <li><a href="<?php echo base_url('Ccustomer/credit_customer')?>"><?php echo display('credit_customer') ?></a></li>         <?php } ?>
                     <?php if($CI->Groups->checkPermissions($gid, 'customer-paid')){ ?>   
                    <li><a href="<?php echo base_url('Ccustomer/paid_customer')?>"><?php echo display('paid_customer') ?></a></li>
                     <?php } ?>
                </ul>
            </li>
            <!-- Customer menu end -->
                <?php } ?>
            
           <?php if($CI->Groups->checkPermissions($gid, 'category-index') || $CI->Groups->checkPermissions($gid, 'category-add')){ ?>
            <!-- Category menu start -->
            <li class="treeview <?php if ($this->uri->segment('1') == ("Ccategory")) { echo "active";}else{ echo " ";}?>">
                <a href="#">
                    <i class="ti-tag"></i><span><?php echo display('category') ?></span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                     <?php if($CI->Groups->checkPermissions($gid, 'category-add')){ ?>    
                    <li><a href="<?php echo base_url('Ccategory')?>"><?php echo display('add_category') ?></a></li>
                     <?php } ?>
                    <?php if($CI->Groups->checkPermissions($gid, 'category-index')){ ?> 
                    <li><a href="<?php echo base_url('Ccategory/manage_category')?>"><?php echo display('manage_category') ?></a></li>         <?php } ?>
                </ul>
            </li>
            <!-- Category menu end -->
             <?php } ?>
              <?php if($CI->Groups->checkPermissions($gid, 'supplier-index') || $CI->Groups->checkPermissions($gid, 'supplier-add')){ ?>
	        <!-- Supplier menu start -->
	        <li class="treeview <?php if ($this->uri->segment('1') == ("Csupplier")) { echo "active";}else{ echo " ";}?>">
                <a href="#">
                    <i class="ti-user"></i><span><?php echo display('supplier') ?></span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <?php if($CI->Groups->checkPermissions($gid, 'supplier-add')){ ?> 
                    <li><a href="<?php echo base_url('Csupplier')?>"><?php echo display('add_supplier') ?></a></li>
                    <?php } ?> 
                     <?php if($CI->Groups->checkPermissions($gid, 'supplier-index')){ ?> 
                    <li><a href="<?php echo base_url('Csupplier/manage_supplier')?>"><?php echo display('manage_supplier');?></a></li>         <?php } ?> 
                    <?php 
                    if (isset($supplier_ledger)) {
                    ?>
                    <li><a href="<?php echo base_url($supplier_ledger)?>"><?php echo display('supplier_ledger') ?></a></li>
                    <li><a href="<?php echo base_url($supplier_sales_details)?>"><?php echo display('supplier_sales_details') ?></a></li>
                    <li><a href="<?php echo base_url($supplier_sales_summary)?>"><?php echo display('supplier_sales_summary') ?></a></li>
                    <li><a href="<?php echo base_url($sales_payment_actual)?>"><?php echo display('supplier_payment_actual') ?></a></li>
                    <?php
                    }?>
                </ul>
            </li>
            <!-- Supplier menu end -->
            <?php } ?>
            <?php if($CI->Groups->checkPermissions($gid, 'purchase-index') || $CI->Groups->checkPermissions($gid, 'purchase-add')){ ?>
            <!-- Purchase menu start -->
	        <li class="treeview <?php if ($this->uri->segment('1') == ("Cpurchase")) { echo "active";}else{ echo " ";}?>">
                <a href="#">
                    <i class="ti-shopping-cart"></i><span><?php echo display('purchase') ?></span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <?php if($CI->Groups->checkPermissions($gid, 'purchase-add')){ ?> 
                    <li><a href="<?php echo base_url('Cpurchase')?>"><?php echo display('add_purchase') ?></a></li>
                    <?php } ?>
                    <?php if($CI->Groups->checkPermissions($gid, 'purchase-index')){ ?> 
                    <li><a href="<?php echo base_url('Cpurchase/manage_purchase')?>"><?php echo display('manage_purchase') ?></a></li>          <?php } ?>
					<li><a href="<?php echo base_url('Cpurchase/add_purchase_return_form')?>"><?php echo 'Add Purchase Return' ?></a></li>
					<li><a href="<?php echo base_url('Cpurchase/manage_purchase_return')?>"><?php echo 'Manage Purchase Return Order' ?></a></li>
                </ul>
            </li>
            <!-- Purchase menu end -->
               <?php } ?>
            <?php if($CI->Groups->checkPermissions($gid, 'stock-report')){ ?>
            <!-- Stock menu start -->
            <li class="treeview <?php if ($this->uri->segment('1') == ("Creport")) { echo "active";}else{ echo " ";}?>">
                <a href="#">
                    <i class="ti-bar-chart"></i><span><?php echo display('stock') ?></span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo base_url('Creport')?>"><?php echo display('stock_report') ?></a></li>
                </ul>
            </li>
            <!-- Stock menu end -->
            <?php } ?>
            <?php if($CI->Groups->checkPermissions($gid, 'search-customer') || $CI->Groups->checkPermissions($gid, 'search-invoice') || $CI->Groups->checkPermissions($gid, 'search-purchase')){ ?>
            <!-- Search menu start -->
            <li class="treeview <?php if ($this->uri->segment('1') == ("Csearch")) { echo "active";}else{ echo " ";}?>">
                <a href="#">
                    <i class="ti-search"></i><span><?php echo display('search') ?></span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    
                     <?php if($CI->Groups->checkPermissions($gid, 'search-customer')){ ?> 
                    <li><a href="<?php echo base_url('Csearch/customer')?>"><?php echo display('customer') ?> </a></li>
                    <?php } ?>
                    <?php if($CI->Groups->checkPermissions($gid, 'search-invoice')){ ?>  
                   
                    <li><a href="<?php echo base_url('Csearch/invoice')?>"><?php echo display('invoice') ?> </a></li>
                      <?php } ?>
                    <?php if($CI->Groups->checkPermissions($gid, 'search-purchase')){ ?>  
                    <li><a href="<?php echo base_url('Csearch/purchase')?>"><?php echo display('purchase') ?> </a></li>
                     <?php } ?>
					 	
                </ul>
            </li>
            <!-- Search menu end -->
 <?php } ?>
            
             <?php if($CI->Groups->checkPermissions($gid, 'accounts-add') || $CI->Groups->checkPermissions($gid, 'accounts-index') || $CI->Groups->checkPermissions($gid, 'accounts-income') || $CI->Groups->checkPermissions($gid, 'accounts-expense') || $CI->Groups->checkPermissions($gid, 'accounts-tax-index') || $CI->Groups->checkPermissions($gid, 'accounts-tax-add') || $CI->Groups->checkPermissions($gid, 'accounts-summery') || $CI->Groups->checkPermissions($gid, 'accounts-cheque-manager') || $CI->Groups->checkPermissions($gid, 'accounts-closing') || $CI->Groups->checkPermissions($gid, 'accounts-closing-report')){ ?>
 
            <!-- Accounts menu start -->
            <li class="treeview <?php if ($this->uri->segment('1') == ("Caccounts") || $this->uri->segment('2') == ("table_create") || $this->uri->segment('2') == ("table_list") || $this->uri->segment('2') == ("table_edit")) { echo "active";}else{ echo " ";}?>">
                <a href="#">
                    <i class="ti-pencil-alt"></i><span><?php echo display('accounts') ?></span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <?php if($CI->Groups->checkPermissions($gid, 'accounts-add')){ ?> 
                    <li><a href="<?php echo base_url('Csettings/table_create/')?>"><?php echo display('create_accounts') ?> </a></li>
                    <?php } ?>
                    <?php if($CI->Groups->checkPermissions($gid, 'accounts-index')){ ?>   
                    <li><a href="<?php echo base_url('Csettings/table_list/')?>"><?php echo display('manage_accounts') ?> </a></li>
                    <?php } ?>
                    <?php if($CI->Groups->checkPermissions($gid, 'accounts-income')){ ?>   
                    <li><a href="<?php echo base_url('Caccounts')?>"><?php echo display('income') ?></a></li>
                     <?php } ?>
                    <?php if($CI->Groups->checkPermissions($gid, 'accounts-expense')){ ?>   
                    <li><a href="<?php echo base_url('Caccounts/outflow/')?>"><?php echo display('expense') ?></a></li>
                    <?php } ?>
                     <?php if($CI->Groups->checkPermissions($gid, 'accounts-tax-add')){ ?>   
                    <li><a href="<?php echo base_url('Caccounts/add_tax/')?>"><?php echo display('add_tax') ?></a></li>
                    <?php } ?>
                     <?php if($CI->Groups->checkPermissions($gid, 'accounts-tax-index')){ ?> 
                    <li><a href="<?php echo base_url('Caccounts/manage_tax/')?>"><?php echo display('manage_tax') ?></a></li>
                   <?php } ?>
                     <?php if($CI->Groups->checkPermissions($gid, 'accounts-summery')){ ?> 
                    <li><a href="<?php echo base_url('Caccounts/summary/')?>"><?php echo display('accounts_summary') ?></a></li>
                    <?php } ?>
                     <?php if($CI->Groups->checkPermissions($gid, 'accounts-cheque-manager')){ ?> 
                    <li><a href="<?php echo base_url('Caccounts/cheque_manager/')?>"><?php echo display('cheque_manager') ?></a></li>
                     <?php } ?>
                     <?php if($CI->Groups->checkPermissions($gid, 'accounts-closing')){ ?> 
                    <li><a href="<?php echo base_url('Caccounts/closing/')?>"><?php echo display('closing') ?></a></li>
                   <?php } ?>
                     <?php if($CI->Groups->checkPermissions($gid, 'accounts-closing-report')){ ?> 
                    <li><a href="<?php echo base_url('Caccounts/closing_report/')?>"><?php echo display('closing_report') ?></a></li>
                    <?php } ?>
                     
                </ul>
            </li>
            <!-- Accounts menu end -->
           <?php } ?>
            <?php if($CI->Groups->checkPermissions($gid, 'reports-index') || $CI->Groups->checkPermissions($gid, 'reports-sales') || $CI->Groups->checkPermissions($gid, 'reports-purchase') || $CI->Groups->checkPermissions($gid, 'reports-sales-product-wise') || $CI->Groups->checkPermissions($gid, 'reports-profit')){ ?>
            <!-- Report menu start -->
            <li class="treeview <?php if ($this->uri->segment('2') == ("all_report") || $this->uri->segment('2') == ("todays_sales_report") || $this->uri->segment('2') == ("todays_purchase_report") || $this->uri->segment('2') == ("product_sales_reports_date_wise") || $this->uri->segment('2') == ("total_profit_report") ) { echo "active";}else{ echo " ";}?>">
                <a href="#">
                    <i class="ti-book"></i><span><?php echo display('report') ?></span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <?php if($CI->Groups->checkPermissions($gid, 'reports-index')){ ?> 
                    <li><a href="<?php echo base_url('Admin_dashboard/all_report')?>"><?php echo display('todays_report') ?></a></li>
                    <?php } ?>
                    <?php if($CI->Groups->checkPermissions($gid, 'reports-sales')){ ?> 
                    <li><a href="<?php echo base_url('Admin_dashboard/todays_sales_report')?>"><?php echo display('sales_report') ?></a></li>
					<li><a href="<?php echo base_url('Admin_dashboard/todays_bulk_sales_report')?>">Bulk <?php echo display('sales_report') ?></a></li>		          <?php } ?>
					 
                     <?php if($CI->Groups->checkPermissions($gid, 'reports-purchase')){ ?>  
                    <li><a href="<?php echo base_url('Admin_dashboard/todays_purchase_report')?>"><?php echo display('purchase_report') ?></a></li>
                   <?php } ?>
                     <?php if($CI->Groups->checkPermissions($gid, 'reports-sales-product-wise')){ ?>   
                    <li><a href="<?php echo base_url('Admin_dashboard/product_sales_reports_date_wise')?>"><?php echo display('sales_report_product_wise') ?></a></li>
                    <?php } ?>   
                   <?php if($CI->Groups->checkPermissions($gid, 'reports-profit')){ ?> 
                    <li><a href="<?php echo base_url('Admin_dashboard/total_profit_report')?>"><?php echo display('profit_report') ?></a></li>       
          <?php } ?>   
		             <li><a href="<?php echo base_url('Admin_dashboard/daily_cash_report')?>"><?php echo 'Daily Cash Report' ?></a></li>
					
                </ul>
            </li>
            <!-- Report menu end -->
           <?php } ?>   
           <?php if($CI->Groups->checkPermissions($gid, 'bank-index') || $CI->Groups->checkPermissions($gid, 'bank-add')){ ?>
            <!-- Bank menu start -->
            <li class="treeview <?php if ($this->uri->segment('2') == ("index") || $this->uri->segment('2') == ("bank_list")) { echo "active";}else{ echo " ";}?>">
                <a href="#">
                    <i class="ti-briefcase"></i><span><?php echo display('settings') ?></span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                     <?php if($CI->Groups->checkPermissions($gid, 'bank-add')){ ?> 
                    <li><a href="<?php echo base_url('Csettings/index')?>"><?php echo display('add_new_bank') ?></a></li>
                    <?php } ?>  
                    <?php if($CI->Groups->checkPermissions($gid, 'bank-index')){ ?> 
                    <li><a href="<?php echo base_url('Csettings/bank_list/')?>"><?php echo display('manage_bank') ?></a></li>
                     <?php } ?>  
                </ul>
            </li>
            <!-- Bank menu end -->
             <?php } ?>   
  
          
	    </ul>

          <?php } ?>
	</div> <!-- /.sidebar -->
</aside>