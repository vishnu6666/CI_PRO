<!-- Closing container start -->
<table class="table table-striped table-bordered">
	<tr>
		<td><center>Drawing</center></td>
		<td><center>Expenses</center></td>
	</tr>
	<tr>
		<td>{drawing_view}</td>
		<td>{transaction_view}</td>
	</tr>
	<tr>
		<td><center>Banking</center></td>
		<td><center>Daily Closing</center></td>
	</tr>
	<tr>
		<td>{bank_view}</td>
		<td>{closing_html}</td>
	</tr>
</table>
<!-- Closing container end -->
