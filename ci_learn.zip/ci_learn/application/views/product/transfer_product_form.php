<!-- Product Purchase js -->
<script src="<?php echo base_url()?>my-assets/js/admin_js/json/product_purchase.js.php" ></script>
<!-- Purchase js -->
<script src="<?php echo base_url()?>my-assets/js/admin_js/purchase.js" type="text/javascript"></script>
<!-- Product Purchase js -->
<script src="<?php echo base_url()?>my-assets/js/admin_js/json/product_invoice.js.php" ></script>
<!-- Invoice js -->
<script src="<?php echo base_url()?>my-assets/js/admin_js/invoice.js" type="text/javascript"></script>
<!-- Add New Purchase Start -->
<div class="content-wrapper">
    <section class="content-header">
        <div class="header-icon">
            <i class="pe-7s-note2"></i>
        </div>
        <div class="header-title">
            <h1><?php echo 'Transfer Product' ?></h1>
            <small><?php echo 'transfer Product' ?></small>
            <ol class="breadcrumb">
                <li><a href="#"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
                <li><a href="#"><?php echo display('product') ?></a></li>
                <li class="active"><?php echo 'Transfer Product' ?></li>
            </ol>
        </div>
    </section>
    <section class="content">
        <!-- Alert Message -->
        <?php
            $message = $this->session->userdata('message');
            if (isset($message)) {
        ?>
        <div class="alert alert-info alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $message ?>                    
        </div>
        <?php 
            $this->session->unset_userdata('message');
            }
            $error_message = $this->session->userdata('error_message');
            if (isset($error_message)) {
        ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $error_message ?>                    
        </div>
        <?php 
            $this->session->unset_userdata('error_message');
            }
        ?>

        <!-- Purchase report -->
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4><?php echo 'Transfer Product' ?></h4>
                        </div>
                    </div>

                    <div class="panel-body">
                   <?php echo form_open_multipart('Cproduct/transfer_product_entry')?>     
						
				
	
                        <div class="table-responsive" style="margin-top: 10px">
                            <table class="table table-bordered table-hover" id="purchaseTable">
                                <thead>
                                    <tr>
                                       
                                        <th class="text-center"><?php echo 'Product' ?></th>             

                                        <th class="text-center">Total <?php echo display('quantity') ?> </th>   
                                        <th class="text-center">Transfer <?php echo display('quantity') ?> </th>     
                                        <th class="text-center"><?php echo display('company') ?> </th>  										
                                        
                                    </tr>
                                </thead>
                                <tbody id="addPurchaseItem">
                                    <tr>
                                       
                                        <td class="span3 supplier"><input type="text" name="product_name" onkeypress="purchase_productList(1);" class="form-control productSelection" placeholder='<?php echo 'Product Name' ?>' required="" id="product_name" >
                                            <input type="hidden" class="autocomplete_hidden_value product_id_1" name="row_product_id[]" id="SchoolHiddenId"/>                       <input type="hidden" class="baseUrl" value="<?php echo base_url();?>" />
											<input type="hidden" class="prid_1" name="prid"  />
                                        </td>
                                        
                                        <td class="text-right">
                                            <input type="text" name="product_quantity" id="total_qntt_1" class="form-control text-right total_quantity_1" placeholder="<?php echo display('quantity') ?>" value='1' readonly="" min="0" required />
                                        </td>
										
										  <td class="text-right">
                                            <input type="text" name="transfer_product_quantity" id="total_qntt_1" class="form-control text-right" placeholder="<?php echo display('quantity') ?>"  required />
                                        </td>
										
										  <td class="text-right">
                                            <select name="company_id" class="form-control" required > 
				                <option> <?php echo display('all') ?> </option>
				                {company_list}
				               <option value="{id}">{company_name}</option>
				                {/company_list}
                                              <?php if($company_id){ ?>
                                               <option value="{company_id}" selected>{c_name}</option>
                                              <?php } ?>

               
				        </select>
                                        </td>


                                        
                                                                           
                                    
                                    </tr>
                                </tbody>
                               
                                 
                            </table>
                        </div>

                        <div class="form-group row">
                            <div class="col-sm-6">
                                <input type="submit" id="add-product" class="btn btn-primary btn-large" name="add-product" value="<?php echo display('submit') ?>" />
                                <input type="submit" value="<?php echo display('submit_and_add_another') ?>" name="add-product-another" class="btn btn-large btn-success" id="add-product-another">
                            </div>
                        </div>
                    <?php echo form_close()?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<!-- Purchase Report End -->


