<!-- Product Purchase js -->
<script src="<?php echo base_url()?>my-assets/js/admin_js/json/product_purchase.js.php" ></script>
<!-- Purchase js -->
<script src="<?php echo base_url()?>my-assets/js/admin_js/purchase.js" type="text/javascript"></script>
<!-- Product Purchase js -->
<script src="<?php echo base_url()?>my-assets/js/admin_js/json/product_invoice.js.php" ></script>
<!-- Invoice js -->
<script src="<?php echo base_url()?>my-assets/js/admin_js/invoice.js" type="text/javascript"></script>
<!-- Add New Purchase Start -->
<div class="content-wrapper">
    <section class="content-header">
        <div class="header-icon">
            <i class="pe-7s-note2"></i>
        </div>
        <div class="header-title">
            <h1><?php echo 'Edit Product Mapping' ?></h1>
            <small><?php echo 'Edit New Product Mapping' ?></small>
            <ol class="breadcrumb">
                <li><a href="#"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
                <li><a href="#"><?php echo display('product') ?></a></li>
                <li class="active"><?php echo 'Edit Product Mapping' ?></li>
            </ol>
        </div>
    </section>
    <section class="content">
        <!-- Alert Message -->
        <?php
            $message = $this->session->userdata('message');
            if (isset($message)) {
        ?>
        <div class="alert alert-info alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $message ?>                    
        </div>
        <?php 
            $this->session->unset_userdata('message');
            }
            $error_message = $this->session->userdata('error_message');
            if (isset($error_message)) {
        ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $error_message ?>                    
        </div>
        <?php 
            $this->session->unset_userdata('error_message');
            }
        ?>

        <!-- Purchase report -->
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4><?php echo 'Edit Product Mapping' ?></h4>
                        </div>
                    </div>

                    <div class="panel-body">
                   <?php echo form_open_multipart('Cproduct/update_product_mapping')?>
                        

                       
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group row">
                                    <label for="invoice_no" class="col-sm-4 col-form-label"><?php echo 'Product' ?>
                                       
                                    </label>
                                    <div class="col-sm-8">
                                        <input type="text" name="product_name" onkeypress="invoice_productList(1);" class="form-control productSelection" placeholder='<?php echo 'Product Name' ?>' required="" id="product_name" value="{product_name}" >
 <input type="hidden" class="autocomplete_hidden_value product_id_1" name="product_id" value="{product_id}" id="SchoolHiddenId"/>                       <input type="hidden" class="baseUrl" value="<?php echo base_url();?>" />
                                    </div>
                                </div>
                            </div>

                           
                        </div>
				

                      
						
				
	
                        <div class="table-responsive" style="margin-top: 10px">
                            <table class="table table-bordered table-hover" id="purchaseTable">
                                <thead>
                                  <tr>
                                       
                                        <th class="text-center"><?php echo 'Product Raw Material' ?></th>                                      

                                        <th class="text-center"><?php echo display('quantity') ?> </th>   
                                        <th class="text-center"><?php echo 'Price' ?> </th>
<th class="text-center"><?php echo 'Total Price' ?> </th> 
										
                                      
                                        <th class="text-center"><?php echo display('action') ?></th>
                                    </tr>
                                </thead>
                                <tbody id="addPurchaseItem">
                                   {product_list}
                                    <tr>
                                       
                                        <td class="span3 supplier"><input type="text" name="product_name" onkeypress="invoice_productList2({sl});" class="form-control productSelection" placeholder='<?php echo 'Product Name' ?>' required="" id="product_name" value="{product_name}" >
                                            <input type="hidden" class="autocomplete_hidden_value product_id_{sl}" name="row_product_id[]" value="{map_product_id}" id="SchoolHiddenId"/>                       <input type="hidden" class="baseUrl" value="<?php echo base_url();?>" />
                                        </td>
                                           <td class="text-right">
                                            <input type="text" name="product_quantity[]" id="total_qntt_{sl}" onkeyup="quantity_calculate2({sl});"  class="form-control text-right" value="{quantity}"  placeholder="<?php echo display('quantity') ?>" min="0" required />
                                        </td>
                                          <td class="text-right">
                                            <input type="text" name="product_price[]" id="price_item_{sl}" onkeyup="quantity_calculate2({sl});" class="price_item{sl} text-right form-control"  value="{pprice}"  placeholder="Price" min="0" required />
                                        </td>       
                                        <td class="text-right">
                                          			
                                       <input class="total_price text-right form-control" type="text" name="total_price[]" id="total_price_{sl}" value="{total_price}"  readonly="" /> 
                                        </td>
								
                                       
                                        
                                                                           
                                        <td>    
                                            <button style="text-align: right;" class="btn btn-danger" type="button" value="Delete" onclick="deleteRow(this)">Delete</button>
                                        </td>
                                    </tr>
                                     {/product_list}
                                </tbody>
                                <tfoot>
                                     <tr>
                                       <td></td>
                                     
                                        <td style="text-align:right;" colspan="2"><b><?php echo display('grand_total') ?>:</b></td>
                                        <td class="text-right" >
                                            <input type="text" id="grandTotal" value="{grand_total}"  class="text-right form-control" name="grand_total_price" tabindex="-1" value="0.00" readonly />
                                        </td>
                                    </tr>

                                   
                                </tfoot>
                            </table>
                        </div>

                        <div class="form-group row">
                            <div class="col-sm-6">
                                <input type="submit" id="add-product" class="btn btn-primary btn-large" name="add-product" value="<?php echo display('submit') ?>" />
                               
                            </div>
                        </div>
                    <?php echo form_close()?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<!-- Purchase Report End -->


