<!-- Customer js php -->
<script src="<?php echo base_url()?>my-assets/js/admin_js/json/customer.js.php" ></script>
<!-- Product invoice js -->
<script src="<?php echo base_url()?>my-assets/js/admin_js/json/product_invoice.js.php" ></script>
<!-- Invoice js -->
<script src="<?php echo base_url()?>my-assets/js/admin_js/invoice.js" type="text/javascript"></script>

<!-- Add new invoice start -->
<style>
	#bank_info_hide
	{
		display:none;
	}
    #payment_from_2
    {
        display:none;
    }
</style>

<!-- Customer type change by javascript start -->
<script type="text/javascript">
	function bank_info_show(payment_type)
	{
	    if(payment_type.value=="1"){
	        document.getElementById("bank_info_hide").style.display="none";
	    }
	    else{ 
	        document.getElementById("bank_info_hide").style.display="block";  
	    }
	}
    //Customer old/new    
    function active_customer(status)
    {
	    if(status=="payment_from_2"){
	        document.getElementById("payment_from_2").style.display="none";
	        document.getElementById("payment_from_1").style.display="block";
	        document.getElementById("myRadioButton_2").checked = false;
	        document.getElementById("myRadioButton_1").checked = true;
	    }
	    else{
	        document.getElementById("payment_from_1").style.display="none";
	        document.getElementById("payment_from_2").style.display="block";
	        document.getElementById("myRadioButton_2").checked = false;
	        document.getElementById("myRadioButton_1").checked = true;
	    }
    }
    //Payment method toggle 
    $(document).ready(function(){
        $("#payment_method").change(function(){
            if($("#payment_method").val()=='Cheque'){
			    document.getElementById("chequeid").style.display="block";
				document.getElementById("bankid").style.display="block";
			}else{
			    document.getElementById("chequeid").style.display="none";
				document.getElementById("bankid").style.display="none";
			}
        });
    });
</script>
<!-- Customer type change by javascript end -->

<!-- Add New Invoice Start -->
<div class="content-wrapper">
    <section class="content-header">
        <div class="header-icon">
            <i class="pe-7s-note2"></i>
        </div>
        <div class="header-title">
            <h1><?php echo 'Add Wholesale Return'; ?></h1>
            <small><?php echo 'Add Wholesale Return'; ?></small>
            <ol class="breadcrumb">
                <li><a href="#"><i class="pe-7s-home"></i> <?php echo 'Home'; ?></a></li>
                <li><a href="#"><?php echo 'Wholesale Return'; ?></a></li>
                <li class="active"><?php echo 'Add Wholesale Return'; ?></li>
            </ol>
        </div>
    </section>

    <section class="content">
        <!-- Alert Message -->
        <?php
            $message = $this->session->userdata('message');
            if (isset($message)) {
        ?>
        <div class="alert alert-info alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $message ?>                    
        </div>
        <?php 
            $this->session->unset_userdata('message');
            }
            $error_message = $this->session->userdata('error_message');
            if (isset($error_message)) {
        ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $error_message ?>                    
        </div>
        <?php 
            $this->session->unset_userdata('error_message');
            }
        ?>
        <!--Add Invoice -->
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4><?php echo 'Add Wholesale Return' ?></h4>
                        </div>
                    </div>
                    <?php echo form_open_multipart('Cadvancedinvoice/insert_wholesale_return',array('class' => 'form-vertical', 'id' => 'insert_wholesale_return','name' => 'insert_wholesale_return'))?>
                    <div class="panel-body">
                     

                       
                        <div class="row">
                        	<div class="col-sm-6">
                                <div class="form-group row">
                                    <label for="date" class="col-sm-4 col-form-label"><?php echo 'Bulk Invoice NO' ?> <i class="text-danger">*</i> </label>
                                    <div class="col-sm-8">
                                      <input type="text"  size="100" name="advancedinvoice_id" class=" form-control" placeholder='<?php echo 'Bulk Invoice NO' ?>' id="advancedinvoice_id" required="" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    

                        <div class="table-responsive" style="margin-top: 10px">
                            <table class="table table-bordered table-hover" id="normalinvoice">
                                <thead>
                                    <tr>
                                        <th class="text-center"><?php echo 'Item Name' ?> <i class="text-danger">*</i></th>										
										 <th class="text-center"><?php echo 'PTR' ?></th>
                                        <th class="text-center"><?php echo display('quantity') ?> <i class="text-danger">*</i></th>
                                        <th class="text-center"><?php echo display('rate') ?> <i class="text-danger">*</i></th>
                                        <th class="text-center"><?php echo display('discount') ?> </th>
                                        <th class="text-center"><?php echo display('total') ?> <i class="text-danger">*</i></th>
                                      
                                    </tr>
                                </thead>
                                <tbody id="addinvoiceItem">
                                    <tr>
                                        <td>
                                            <input type="text" name="product_name" onkeypress="invoice_productList(1);" class="form-control productSelection" placeholder='<?php echo 'Item Name' ?>' required="" id="product_name" >
                                            <input type="hidden" class="autocomplete_hidden_value product_id_1" name="product_id[]" id="SchoolHiddenId"/>                       <input type="hidden" class="baseUrl" value="<?php echo base_url();?>" />
                                        </td>
										  <td>
                                            <input type="text" name="ptr[]" id="" class="form-control text-right ptr_1"   />
                                        </td>
									
                                        <td width="150">
                                            <input type="text" name="product_quantity[]" onkeyup="quantity_calculate(1);" id="total_qntt_1" class="form-control text-right" value="1" required  />
                                        </td>
                                        <td width="150">
                                          <input type="number" name="product_rate[]" readonly="" value="0.00" id="price_item_1" class="price_item1 form-control text-right" /><input type="hidden" name="product_tax[]" readonly="" value="0.00" id="tax_item_1" class="tax_item1 form-control text-right" /><input type="hidden" name="product_sgst[]" readonly="" value="0.00" id="sgst_item_1" class="sgst_item1 form-control text-right" />
                                        </td>
					 <td width="150"><input type="text" name="discount[]" onkeyup="quantity_calculate(1);" id="discount_1" class="form-control text-right" value="0" min="1" />	
                                        </td>                                        
                                        <td width="150">
                                            <input class="total_price form-control text-right" type="text" name="total_price[]" id="total_price_1" value="0.00" tabindex="-1" readonly="readonly" />
                                     
                                            <!-- Tax calculate start-->
                                            <input type="hidden" id="total_tax_1" class="total_tax_1" />
                                            <input type="hidden" id="total_cgst_1" class="total_cgst" />
                                            <input type="hidden" id="total_sgst_1" class="total_sgst" />
                                            <input type="hidden" id="all_tax_1" class="total_tax"/>
                                            <!-- Tax calculate end -->
                                          
                                        </td>
                                    </tr>
                                </tbody>
                                <tfoot>
                                   
                                 
                                    <tr> 
									 <td></td>
									  <td></td>
                                        <td  class="text-right">
                                           
                                        </td>
                                       
<td colspan="2" style="text-align:right;"><b><?php echo display('grand_total') ?>:</b></td><td>  <input type="text" id="grandTotal" tabindex="-1" class="form-control text-right" name="grand_total_price" value="0.00" readonly="readonly" /></td>
                                        
                                    </tr>
                                
                                    <tr>
                                        <td align="center"> <input type="hidden" name="baseUrl" class="baseUrl" value="<?php echo base_url();?>"/>        <input type="submit" id="add-invoice" class="btn btn-success" name="add-invoice" value="<?php echo display('save_and_paid') ?>" />
                                            
                                        </td>                       

                                       
 <td style="text-align:right;" colspan="4"></td>
                                        <td class="text-right"> 
                                        </td>
                                       

                                    </tr>
							
									 <tr class="payment_method" >
                                        <td colspan="5">
                                            <div class="row">
                                                <div class="col-sm-7">
                                                    <div class="form-group row">
                                                        <label for="payment_method" class="col-sm-4 col-form-label"><?php echo 'Return Reason' ?>: </label>
                                                        <div class="col-sm-8">
                                                            <select class="form-control" name="return_reason" id="return_reason" required>
															   <option value="">Select Return Reason</option>
                                                                <option value="Return Due to Expiry">Return Due to Expiry</option>
                                                                <option value="Due to Not Moving">Due to Not Moving</option>
																<option value="Other">Others</option>                                                     
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        
                                        </td>
                                    </tr>
									</tfoot>
                            </table>
                        </div>
                    </div>
                    <?php echo form_close()?>
                </div>
            </div>
        </div>
    </section>
</div>
<!-- Invoice Report End -->
<!-- JS -->
<script type="text/javascript">
  //Product select by ajax start
    $('body').on('change','#advancedinvoice_id',function(event){
        event.preventDefault(); 
        var advancedinvoice_id=$('#advancedinvoice_id').val();
        var csrf_test_name=  $("[name=csrf_test_name]").val();
		alert(advancedinvoice_id);
        $.ajax({
            url: '<?php echo base_url('Cadvancedinvoice/retrieve_wholesale_return_product_data')?>',
            type: 'post',
            data: {advancedinvoice_id:advancedinvoice_id,csrf_test_name:csrf_test_name}, 
            success: function (msg){
                $("#addinvoiceItem").html(msg);
            },
            error: function (xhr, desc, err){
                 alert('failed');
            }
        });        
    });
    //Product select by ajax end
</script>