<!-- Add new bank start -->
<div class="content-wrapper">
    <section class="content-header">
        <div class="header-icon">
            <i class="pe-7s-note2"></i>
        </div>
        <div class="header-title">
            <h1><?php echo "Add New Salary" ?></h1>
            <small><?php echo "Add Salary"; ?></small>
            <ol class="breadcrumb">
                <li><a href="#"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
                <li><a href="#"><?php echo display('settings') ?></a></li>
                <li class="active"><?php echo "Add New Salary"; ?></li>
            </ol>
        </div>
    </section>

    <section class="content">
         <!-- Alert Message -->
        <?php
            $message = $this->session->userdata('message');
            if (isset($message)) {
        ?>
        <div class="alert alert-info alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $message ?>                    
        </div>
        <?php 
            $this->session->unset_userdata('message');
            }
            $error_message = $this->session->userdata('error_message');
            if (isset($error_message)) {
        ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $error_message ?>                    
        </div>
        <?php 
            $this->session->unset_userdata('error_message');
            }
        ?>
        <!-- New bank -->
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4><?php echo "Add New Salary"; ?> </h4>
                        </div>
                    </div>
                   <?php echo form_open_multipart('Csalary/add_salary_book',array('class' => 'form-vertical','id' => 'insert_deposit' ))?>
                    <div class="panel-body">

                         <div class="form-group row">
                            <label for="staff" class="col-sm-3 col-form-label">Staff <i class="text-danger">*</i></label>
                            <div class="col-sm-6">
                                <select class="form-control" name="staff" id="staff">
                                    {salary_list}
                                     <option value="{user_id}">{first_name}  {last_name}</option>
                                    {/salary_list}  
                                  
                                  </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="working_days" class="col-sm-3 col-form-label"><?php echo "Working days" ?> <i class="text-danger">*</i></label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="working_days" id="working_days" required="" placeholder="Working days" />
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="late_coming" class="col-sm-3 col-form-label"><?php echo "Late Comming";?> <i class="text-danger"></i></label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="late_coming" id="late_coming"  placeholder="Late Comming" />
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="over_time" class="col-sm-3 col-form-label">Over time <i class="text-danger"></i></label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="over_time" id="over_time"  placeholder="Over time" />
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="half_day" class="col-sm-3 col-form-label"><?php echo "Half Day";?> <i class="text-danger"></i></label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="half_day" id="half_day"  placeholder="Half Day" />
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="leave" class="col-sm-3 col-form-label">Leave <i class="text-danger"></i></label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="leave" id="leave" placeholder="Leave" />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="date" class="col-sm-3 col-form-label"><?php echo 'Date' ?> </label>
                            <div class="col-sm-6">
                                <input class="form-control datepicker" name ="date" id="date" type="text" placeholder="<?php echo 'Date' ?>"  >
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="example-text-input" class="col-sm-4 col-form-label"></label>
                            <div class="col-sm-6">
                                <input type="submit" id="add-deposit" class="btn btn-success" name="add-deposit" value="<?php echo display('save') ?>" />
                            </div>
                        </div>
                    </div>
                    <?php echo form_close()?>
                </div>
            </div>
        </div>
    </section>
</div>
<!-- Add new bank end -->



