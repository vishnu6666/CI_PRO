<!-- Account List Start -->
<div class="content-wrapper">
	<section class="content-header">
	    <div class="header-icon">
	        <i class="pe-7s-note2"></i>
	    </div>
	    <div class="header-title">
	        <h1>Bankwise Statment</h1>
	        <small>Bankwise Statment</small>
	        <ol class="breadcrumb">
	            <li><a href="#"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
	            <li><a href="#"><?php echo display('settings') ?></a></li>
	            <li class="active">Bankwise Statment</li>
	        </ol>
	    </div>
	</section>

	<section class="content">

		<!-- Alert Message -->
        <?php
            $message = $this->session->userdata('message');
            if (isset($message)) {
        ?>
        <div class="alert alert-info alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $message ?>                    
        </div>
        <?php 
            $this->session->unset_userdata('message');
            }
            $error_message = $this->session->userdata('error_message');
            if (isset($error_message)) {
        ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $error_message ?>                    
        </div>
        <?php 
            $this->session->unset_userdata('error_message');
            }
        ?>

		<!-- Account List -->
		<div class="row">
		    <div class="col-sm-12">
		        <div class="panel panel-bd lobidrag">
		            <div class="panel-heading">
		                <div class="panel-title">
		                    <h4>Bankwise Statment</h4>
		                </div>
		            </div>
		            <div class="panel-body">
		                <div class="table-responsive">
		                    <table id="dataTableExample2" class="table table-bordered table-striped table-hover">
			           			<thead>
									<tr>
										
										<th>Date</th>
										<th>From / To</th>
										<th>Amount</th>
										<th>Credit/Debit</th>
										<th>Bank Name</th>
										<th>Balance</th>
										<td>Description</td>
									</tr>
									</thead>
									<tbody>
									<?php
										if ($bank_statment_by_income_id) {
									?>
									{bank_statment_by_income_id}
										<tr>
										
											<td>{date}</td>
											<td>{customer_name}</td>
											<td>{amount}</td>
											<td>Credit</td>
											<td>{bank_name}</td>
											<td><b>{total_credit}&nbsp; &nbsp;&#8360;</b></td>
											<td>{description}</td>
											
										</tr>
									{/bank_statment_by_income_id}
									<?php
										}
									?>
									<?php
										if ($bank_statment_by_expence_id) {
									?>
									{bank_statment_by_expence_id}
										<tr>	
											<td>{date}</td>
											<td>{supplier_name}</td>
											<td>{amount}</td>
											<td>Debit</td>
											<td>{bank_name}</td>
											<td><b>{total_debit}&nbsp; &nbsp;&#8360;</b></td>
											<td>{description}</td>
										</tr>
									{/bank_statment_by_expence_id}
									<?php
										}
									?>
									</tbody>
					
		                    </table>
		                    <div>
									<a href="<?php echo base_url('Csettings/bank_statment'); ?>" class="btn btn-info" role="button">Go Back</a>
						
							</div>
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
	</section>
</div>
<!-- Account List End -->

