<!-- Edit new bank start -->
<div class="content-wrapper">
    <section class="content-header">
        <div class="header-icon">
            <i class="pe-7s-note2"></i>
        </div>
        <div class="header-title">
            <h1><?php echo display('bank_edit') ?></h1>
            <small><?php echo display('bank_edit') ?></small>
            <ol class="breadcrumb">
                <li><a href="#"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
                <li><a href="#"><?php echo display('settings') ?></a></li>
                <li class="active"><?php echo display('bank_edit') ?></li>
            </ol>
        </div>
    </section>

    <section class="content">

        <!-- Alert Message -->
        <?php
            $message = $this->session->userdata('message');
            if (isset($message)) {
        ?>
        <div class="alert alert-info alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $message ?>                    
        </div>
        <?php 
            $this->session->unset_userdata('message');
            }
            $error_message = $this->session->userdata('error_message');
            if (isset($error_message)) {
        ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $error_message ?>                    
        </div>
        <?php 
            $this->session->unset_userdata('error_message');
            }
        ?>


        <!-- New bank -->
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4><?php echo display('bank_list') ?></h4>
                        </div>
                    </div>
                   <?php echo form_open_multipart('Csettings/update_bank/'.$bank_list[0]['bank_id'],array('class' => 'form-vertical','id' => 'insert_deposit' ))?>
                    <div class="panel-body">

                        <div class="form-group row">
                            <label for="bank_name" class="col-sm-3 col-form-label"><?php echo display('bank_name') ?> <i class="text-danger">*</i></label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="bank_name" id="bank_name" required="" placeholder="<?php echo display('bank_name') ?>" value="<?php echo $bank_list[0]['bank_name']?>"/>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="acount_no" class="col-sm-3 col-form-label"><?php echo "Account No" ?> <i class="text-danger">*</i></label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="acount_no" id="acount_no" required="" placeholder="<?php echo "Account No" ?>" value="<?php echo $bank_list[0]['acount_no']?>" />
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="branch_name" class="col-sm-3 col-form-label"><?php echo "Branch Name" ?> <i class="text-danger">*</i></label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="branch_name" id="branch_name" required="" placeholder="<?php echo "Branch Name" ?>" value="<?php echo $bank_list[0]['branch_name']?>" />
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="address" class="col-sm-3 col-form-label"><?php echo "Address" ?> <i class="text-danger">*</i></label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="address" id="address" required="" placeholder="<?php echo "Address" ?>" value="<?php echo $bank_list[0]['address']?>"/>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="ifsc" class="col-sm-3 col-form-label"><?php echo "IFSC" ?> <i class="text-danger">*</i></label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="ifsc" id="ifsc" required="" placeholder="<?php echo "IFSC" ?>" value="<?php echo $bank_list[0]['ifsc']?>"/>
                            </div>
                        </div>

                         <div class="form-group row">
                            <label for="amount_present" class="col-sm-3 col-form-label"><?php echo "Amount at present" ?> <i class="text-danger">*</i></label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="amount_present" id="amount_present" required="" placeholder="<?php echo "Amount at present" ?>" value="<?php echo $bank_list[0]['amount_present']?>"/>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="example-text-input" class="col-sm-4 col-form-label"></label>
                            <div class="col-sm-6">
                                <input type="submit" id="add-deposit" class="btn btn-success" name="add-deposit" value="<?php echo display('save_changes') ?>" />
                            </div>
                        </div>
                    </div>
                    <?php echo form_close()?>
                </div>
            </div>
        </div>
    </section>
</div>
<!-- Edit new bank end -->



