function addInputField(t) {
    if (count == limits) alert("You have reached the limit of adding " + count + " inputs");
    else {
        var a = "product_name" + count,
            e = document.createElement("tr");
        e.innerHTML = "<td><input type='text' name='product_name' onkeypress='invoice_productList(" + count + ");' class='form-control productSelection' placeholder='Product Name' id='" + a + "' required><input type='hidden' class='autocomplete_hidden_value  product_id_" + count + "' name='product_id[]' id='SchoolHiddenId'/></td><td><input type='number' name='available_quantity[]' id='' class='form-control text-right available_quantity_" + count + "' value='0' readonly='' /></td><td class='text-right'><input type='number' name='product_quantity[]' id='total_qntt_" + count + "' onkeyup='quantity_calculate(" + count + "); stockLimit(" + count + ");' class='total_qntt" + count + " form-control text-right' value='1'/></td><td><input type='number' name='product_rate[]' readonly value='0.00' id='price_item_" + count + "' class='price_item" + count + " form-control text-right' required/><input type='hidden' name='product_tax[]' readonly value='0.00' id='tax_item_" + count + "' class='tax_item" + count + " form-control text-right' /><input type='hidden' name='product_sgst[]' readonly value='0.00' id='sgst_item_" + count + "' class='sgst_item" + count + " form-control text-right' /></td><td><input type='text' name='discount[]' onkeyup='quantity_calculate(" + count + ");stockLimit(" + count + ");' id='discount_" + count + "' class='form-control text-right' value='0' min='1' /></td><td class='text-right'><input class='total_price form-control text-right' type='text' name='total_price[]' id='total_price_" + count + "' value='0.00' readonly='readonly'/></td><td><input type='hidden' id='total_tax_" + count + "' class='total_tax_" + count + "' /><input type='hidden' id='total_cgst_" + count + "' class='total_cgst' /><input type='hidden' id='total_sgst_" + count + "' class='total_sgst' /><input type='hidden' id='all_tax_" + count + "' class='total_tax'/><button style='text-align: right;' class='btn btn-danger' type='button' value='Delete' onclick='deleteRow(this)'>Delete</button></td>", document.getElementById(t).appendChild(e), document.getElementById(a).focus(), count++
    }
}

function addInputField2(t) {
    if (count == limits) alert("You have reached the limit of adding " + count + " inputs");
    else {
        var a = "product_name" + count,
            e = document.createElement("tr");
        e.innerHTML = "<td><input type='text' name='product_name' onkeypress='invoice_productList2(" + count + ");' class='form-control productSelection' placeholder='Item Name' id='" + a + "' required><input type='hidden' class='autocomplete_hidden_value  product_id_" + count + "' name='product_id[]' id='SchoolHiddenId'/></td><td class='text-right'><input type='text' name='product_quantity[]' id='total_qntt_" + count + "' onkeyup='quantity_calculate2(" + count + "); stockLimit(" + count + ");' class='total_qntt" + count + " form-control text-right' value='1'/></td><td><input type='text' readonly='' name='product_rate[]' value='0.00' id='price_item_" + count + "' class='price_item" + count + " form-control text-right' required/><input type='hidden' name='cgst_per[]'  value='0.00' id='cgst_per_" + count + "' class='cgst_per" + count + " form-control text-right' /><input type='hidden' name='sgst_per[]'  value='0.00' id='sgst_per_" + count + "' class='sgst_per" + count +"  form-control text-right' /><input type='hidden' name='product_tax[]' readonly value='0.00' id='tax_item_" + count + "' class='tax_item" + count + " form-control text-right' /><input type='hidden' name='product_sgst[]' readonly value='0.00' id='sgst_item_" + count + "' class='sgst_item" + count + " form-control text-right' /></td><td><input type='text' name='discount[]' onkeyup='quantity_calculate2(" + count + ");stockLimit(" + count + ");' id='discount_" + count + "' class='form-control text-right' value='0' min='1' /></td><td class='text-right'><input class='total_price form-control text-right' type='text' name='total_price[]' id='total_price_" + count + "' value='0.00' readonly='readonly'/></td><td><input type='hidden' id='total_tax_" + count + "' class='total_tax_" + count + "' /><input type='hidden' id='total_cgst_" + count + "' class='total_cgst' /><input type='hidden' id='total_sgst_" + count + "' class='total_sgst' /><input type='hidden' id='all_tax_" + count + "' class='total_tax'/><button style='text-align: right;' class='btn btn-danger' type='button' value='Delete' onclick='deleteRow(this)'>Delete</button></td>", document.getElementById(t).appendChild(e), document.getElementById(a).focus(), count++
    }
}
function quantity_calculate(t) {
    var a = $("#total_qntt_" + t).val(),
        e = $("#price_item_" + t).val(),
        o = $("#discount_" + t).val(),
        l = $("#total_tax_" + t).val();
	
		
		
    if (a > 0) {
         
        var n = a * e;
	$("#total_price_" + t).val(n);
        
    } else {
         
        var n = a * e;
        $("#total_price_" + t).val(n), $("#all_tax_" + t).val(l)
         
    }
    if (o > 0) {	  
	
        var n = a * e;
	var ot = (n * o ) / 100;
	var fn = n - ot;
        $("#total_price_" + t).val(fn), $("#total_tax_" + t).val(l) 
    
    } else if (0 > o) {
       	 var n = (a * e); 
	 $("#total_price_" + t).val(n), $("#total_tax_" + t).val(l)
        
    }
    calculateSum(), invoice_paidamount()
}

function quantity_calculate2(t) {
    var a = $("#total_qntt_" + t).val(),
        e = $("#price_item_" + t).val(),
        o = $("#discount_" + t).val(),
        l = $("#total_tax_" + t).val();
        c1g = $("#tax_item_" + t).val(); 
        cg_per = $("#cgst_per_" + t).val(); 
        var cg;
        var sg;
        sg_per = $("#sgst_per_" + t).val(); 
	cgst = 0;
        sgst = 0; 
        	
       if (a > 0) {
          var n = a * e;
        
          if(cg_per > 0){
             cg = ( n * cg_per) / 100 ;
             var cgst =  cg;
           }
        if(sg_per > 0){
           sg = ( n * sg_per) / 100 ;
           var sgst = sg;  
        }  
     
        $("#total_cgst_" + t).val(cgst);
        $("#total_sgst_" + t).val(sgst);
        $("#total_price_" + t).val(parseFloat(n) + parseFloat(cgst) + parseFloat(sgst));
        var c = a * l;
        $("#all_tax_" + t).val(c)
    } else {
        var n = a * e;
		 if(cg_per > 0){
             cg = ( n * cg_per) / 100 ;
             var cgst =  cg;
           }
        if(sg_per > 0){
           sg = ( n * sg_per) / 100 ;
           var sgst = sg;  
        }  
		$("#total_cgst_" + t).val(cgst);
        $("#total_sgst_" + t).val(sgst);
        $("#total_price_" + t).val(parseFloat(n) + parseFloat(cgst) + parseFloat(sgst)), $("#all_tax_" + t).val(l)
    }
    if (o > 0) {	  
		
        var n = a * e;
	var ot = (n * o ) / 100;
	var nn = n - ot ;
	cg = ( nn * cg_per) / 100 ;
        sg = ( nn * sg_per) / 100 ;
        var fn = nn + cg + sg ;
        $("#total_price_" + t).val(fn), $("#total_tax_" + t).val(l), $("#total_cgst_" + t).val(cg), $("#total_sgst_" + t).val(sg)
    } else if (0 > o) {
	var n = (a * e); 
	if(cg_per > 0){
             cg = ( n * cg_per) / 100 ;
             var cgst =  cg;
        }
        if(sg_per > 0){
           sg = ( n * sg_per) / 100 ;
           var sgst = sg;  
        }  
        var nn = n + cgst + sgst;
		
        $("#total_price_" + t).val(nn), $("#total_tax_" + t).val(l), $("#total_cgst_" + t).val(cgst), $("#total_sgst_" + t).val(sgst)
    }
        
    calculateSum2(), invoice_paidamount2()
}

function quantity_calculate22(t) {
    var a = $("#total_qntt_" + t).val(),
        
        e = $("#ptr_" + t).val(),
        o = $("#discount_" + t).val(),
        l = $("#total_tax_" + t).val();
       
        c1g = $("#tax_item_" + t).val(); 
        cg_per = $("#cgst_per_" + t).val(); 
      
        var cg;
        var sg;
      
           cg = ( e * a * cg_per) / 100 ;
       
         
		sg_per = $("#sgst_per_" + t).val(); 
	
        //pcg =0;
    //    psg = 0;
        cgst = 0;
        sgst = 0; 
      
        if(f > 0){
            var net = e * a;
            var netrate = net / (parseFloat(a) + parseFloat(f));
            $("#netrate_" + t).val(netrate);
            
        }
      
        if(cg > 0){
          //var pcg = (cg * a * 100) / ( e * a ) ;
        }
        s1g = $("#sgst_item_" + t).val(); 
     
           sg = ( e * a * sg_per) / 100 ;
     
        if(sg > 0){
          //var psg = (sg * a * 100) / ( e * a ) ;
        }
	
		
    if (a > 0) {
        var n = a * e;
        
		 if(cg > 0){
           var cgst =  cg;
        }
        if(sg > 0){
           var sgst = sg;  
        }  
      
        $("#total_cgst_" + t).val(cgst);
        $("#total_sgst_" + t).val(sgst);
        $("#total_price_" + t).val(parseFloat(n) + parseFloat(cgst) + parseFloat(sgst));
        var c = a * l;
        $("#all_tax_" + t).val(c)
    } else {
        var n = a * e;
		if(cg > 0){
           var cgst = cg;
        }
        if(sg > 0){
           var sgst = sg;  
        }  
		$("#total_cgst_" + t).val(cgst);
        $("#total_sgst_" + t).val(sgst);
        $("#total_price_" + t).val(parseFloat(n) + parseFloat(cgst) + parseFloat(sgst)), $("#all_tax_" + t).val(l)
    }
   
    if (o > 0) {	  
		
        var n = a * e;
		if(cg > 0){
          //var cgst = cg;
        }
        if(sg > 0){
          // var sgst = sg;  
         } 
		var ot = (n * o ) / 100;
		var nn = n - ot ;
	
           cg = ( nn * cg_per) / 100 ;
           sg = ( nn * sg_per) / 100 ;
		 var fn = nn + cg + sg ;
        $("#total_price_" + t).val(fn), $("#total_tax_" + t).val(l), $("#total_cgst_" + t).val(cg), $("#total_sgst_" + t).val(sg)
    } else if (0 > o) {
		 var n = (a * e); 
		if(cg > 0){
           var cgst = cg;
        }
        if(sg > 0){
           var sgst = sg;  
        }  
        var nn = n + cgst + sgst;
		
        $("#total_price_" + t).val(nn), $("#total_tax_" + t).val(l), $("#total_cgst_" + t).val(cgst), $("#total_sgst_" + t).val(sgst)
    }
        
    calculateSum2(), invoice_paidamount2()
}

function calculateSum() {
    var t = 0,
        a = 0,
        e = 0,
        o = 0;		
	
    $(".total_tax").each(function() {
        isNaN(this.value) || 0 == this.value.length || (a += parseFloat(this.value))
    }), $("#total_tax_ammount").val(a.toFixed(0)), $(".total_price").each(function() {
        isNaN(this.value) || 0 == this.value.length || (t += parseFloat(this.value))
    }), o = a.toFixed(0), e = t, $("#grandTotal").val(+e)
}

function invoice_paidamount() {
    var t = $("#grandTotal").val(),
        a = $("#paidAmount").val(),
        e = t - a;
    $("#dueAmmount").val(e)
}


function calculateSum2() {
    var t = 0,
        a = 0,
        e = 0,
        o = 0;
		cg1 =0;
        sg1 = 0;
		
	$(".total_cgst").each(function() {
        isNaN(this.value) || 0 == this.value.length || (cg1 += parseFloat(this.value))
    }), $("#total_cgst_ammount").val(cg1)
    
   $(".total_sgst").each(function() {
        isNaN(this.value) || 0 == this.value.length || (sg1 += parseFloat(this.value))
    }), $("#total_sgst_ammount").val(sg1)
   
    $(".total_tax").each(function() {
        isNaN(this.value) || 0 == this.value.length || (a += parseFloat(this.value))
    }), $("#total_tax_ammount").val(a.toFixed(0)), $(".total_price").each(function() {
        isNaN(this.value) || 0 == this.value.length || (t += parseFloat(this.value))
    }), o = a.toFixed(0), e = t, $("#grandTotal").val(+e)
}

function invoice_paidamount2() {
    var t = $("#grandTotal").val(),
        a = $("#paidAmount").val(),
        e = t - a;
    $("#dueAmmount").val(e)
}

function stockLimit(t) {
    var a = $("#total_qntt_" + t).val(),
        e = $(".product_id_" + t).val(),
        o = $(".baseUrl").val();
    $.ajax({
        type: "POST",
        url: o + "Cinvoice/product_stock_check",
        data: {
            product_id: e
        },
        cache: !1,
        success: function(e) {
            if (a > Number(e)) {
                var o = "You can purchase maximum " + e + " Items";
                alert(o), $("#qty_item_" + t).val("0"), $("#total_qntt_" + t).val("0"), $("#total_price_" + t).val("0")
            }
        }
    })
}

function stockLimitAjax(t) {
    var a = $("#total_qntt_" + t).val(),
        e = $(".product_id_" + t).val(),
        o = $(".baseUrl").val();
    $.ajax({
        type: "POST",
        url: o + "Cinvoice/product_stock_check",
        data: {
            product_id: e
        },
        cache: !1,
        success: function(e) {
            if (a > Number(e)) {
                var o = "You can purchase maximum " + e + " Items";
                alert(o), $("#qty_item_" + t).val("0"), $("#total_qntt_" + t).val("0"), $("#total_price_" + t).val("0.00"), calculateSum()
            }
        }
    })
}

function deleteRow(t) {
    var a = $("#normalinvoice > tbody > tr").length;
    if (1 == a) alert("There only one row you can't delete.");
    else {
        var e = t.parentNode.parentNode;
        e.parentNode.removeChild(e), calculateSum()
    }
}
var count = 2,
    limits = 500;